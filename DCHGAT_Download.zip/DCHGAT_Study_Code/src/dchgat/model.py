"""Heterogeneous relation attention, semantic paths, and dynamic node states."""
from __future__ import annotations

import math
from collections import defaultdict
import torch
from torch import nn
from torch.nn import functional as F
from torch.utils.checkpoint import checkpoint

from .data import NODE_TYPES, RELATIONS, GraphView


def segmented_softmax(score: torch.Tensor, target: torch.Tensor, count: int):
    """A destination node normalizes its neighbors separately for every attention head."""
    heads = score.shape[1]
    address = target[:, None].expand(-1, heads)
    max_per = score.new_full((count, heads), -1e12)
    max_per.scatter_reduce_(0, address, score, reduce='amax', include_self=True)
    weights = torch.exp(score - max_per[target])
    denom = score.new_zeros((count, heads))
    denom.index_add_(0, target, weights)
    return weights / denom[target].clamp_min(1e-9)


class RelationAttentionLayer(nn.Module):
    def __init__(self, hidden: int = 128, heads: int = 8, dropout: float = 0.5):
        super().__init__()
        if hidden % heads:
            raise ValueError('The hidden width must be divisible by the number of heads.')
        self.hidden, self.heads, self.size = hidden, heads, hidden // heads
        self.query = nn.Linear(hidden, hidden, bias=False)
        self.key = nn.Linear(hidden, hidden, bias=False)
        self.value = nn.Linear(hidden, hidden, bias=False)
        self.attn_source = nn.Parameter(torch.empty(len(RELATIONS), heads, self.size))
        self.attn_target = nn.Parameter(torch.empty(len(RELATIONS), heads, self.size))
        self.relation_scale = nn.Parameter(torch.ones(len(RELATIONS), heads, self.size))
        self.residual = nn.Linear(hidden, hidden)
        self.norm = nn.LayerNorm(hidden)
        self.dropout = dropout
        nn.init.xavier_uniform_(self.attn_source)
        nn.init.xavier_uniform_(self.attn_target)

    def forward(self, x: torch.Tensor, edges, uniform: bool = False):
        n = x.size(0)
        q = self.query(x).view(n, self.heads, self.size)
        k = self.key(x).view(n, self.heads, self.size)
        v = self.value(x).view(n, self.heads, self.size)
        aggregate = torch.zeros_like(v)
        relations_per_node = x.new_zeros(n, 1, 1)
        for r, name in enumerate(RELATIONS):
            if name not in edges:
                continue
            source, target = edges[name]
            if not source.numel():
                continue
            if uniform:
                counts = x.new_zeros(n)
                counts.index_add_(0, target, x.new_ones(len(target)))
                alpha = (1.0 / counts[target].clamp_min(1.0))[:, None].expand(-1, self.heads)
            else:
                raw = (k[source] * self.attn_source[r]).sum(dim=-1)
                raw += (q[target] * self.attn_target[r]).sum(dim=-1)
                raw = F.leaky_relu(raw / math.sqrt(self.size), negative_slope=0.2)
                alpha = segmented_softmax(raw, target, n)
            msg = v[source] * self.relation_scale[r] * F.dropout(alpha, p=self.dropout, training=self.training).unsqueeze(-1)
            per_relation = torch.zeros_like(v)
            per_relation.index_add_(0, target, msg)
            aggregate += per_relation
            relations_per_node[torch.unique(target)] += 1
        aggregate = aggregate / relations_per_node.clamp_min(1)
        y = aggregate.flatten(1)
        return self.norm(F.elu(y) + self.residual(x))


class SemanticAttention(nn.Module):
    """Different two-step paths carry different kinds of cultural context."""
    def __init__(self, hidden: int, dropout: float):
        super().__init__()
        self.transform = nn.Linear(hidden, hidden)
        self.context = nn.Linear(hidden, 1, bias=False)
        self.output = nn.Linear(hidden, hidden)
        self.dropout = dropout

    def forward(self, x, paths):
        choices = [x]
        for p in paths:
            choices.append(torch.sparse.mm(p, x))
        z = torch.stack(choices, dim=1)
        scores = self.context(torch.tanh(self.transform(z))).squeeze(-1)
        weights = F.softmax(scores, dim=1)
        result = (weights.unsqueeze(-1) * z).sum(dim=1)
        return x + F.dropout(self.output(result), p=self.dropout, training=self.training), weights


class DCHGAT(nn.Module):
    def __init__(self, sizes, feature_sizes, hidden=128, heads=8, layers=3, dropout=0.5,
                 use_meta=True, use_temporal=True, use_content=True,
                 use_attention=True, media_slices=None, use_visual=True, use_audio=True):
        super().__init__()
        self.sizes = sizes
        self.dropout = dropout
        self.use_meta = use_meta
        self.use_temporal = use_temporal
        self.use_content = use_content
        self.use_attention = use_attention
        self.media_slices = media_slices or {}
        self.use_visual = use_visual
        self.use_audio = use_audio
        self.encoder = nn.ModuleDict({t: nn.Linear(feature_sizes[t], hidden) for t in NODE_TYPES})
        self.kind = nn.ParameterDict({t: nn.Parameter(torch.zeros(hidden)) for t in NODE_TYPES})
        self.layers = nn.ModuleList(RelationAttentionLayer(hidden, heads, dropout) for _ in range(layers))
        self.meta_video = SemanticAttention(hidden, dropout)
        self.meta_user = SemanticAttention(hidden, dropout)
        self.gru = nn.GRUCell(hidden, hidden)
        self.scope_head = nn.Sequential(nn.Linear(hidden, hidden), nn.ReLU(), nn.Dropout(dropout), nn.Linear(hidden, 1))
        self.peak_head = nn.Sequential(nn.Linear(hidden, hidden), nn.ReLU(), nn.Dropout(dropout), nn.Linear(hidden, 1))
        self.rank_query = nn.Linear(hidden, hidden)
        self.rank_key = nn.Linear(hidden, hidden)
        self.rank_prior = nn.Linear(hidden, 1)

    def _encode(self, features):
        values = []
        for typ in NODE_TYPES:
            inp = features[typ]
            if typ == 'video':
                inp = inp.clone()
                if not self.use_content:
                    inp.zero_()
                else:
                    for modality, on in (('visual', self.use_visual), ('audio', self.use_audio)):
                        if modality in self.media_slices and not on:
                            start, finish = self.media_slices[modality]
                            inp[:, start:finish] = 0
            values.append(self.encoder[typ](inp) + self.kind[typ])
        return torch.cat(values, dim=0)

    def _snapshot(self, features, graph: GraphView, offsets):
        x = self._encode(features)
        for layer in self.layers:
            def apply_layer(z, current=layer):
                return current(F.dropout(z, p=self.dropout, training=self.training),
                               graph.edges, uniform=not self.use_attention)
            if self.training and x.requires_grad:
                x = checkpoint(apply_layer, x, use_reentrant=False)
            else:
                x = apply_layer(x)
        if self.use_meta:
            a = offsets['video']; b = a + self.sizes['video']
            u = self.sizes['user']
            video, vw = self.meta_video(x[a:b], graph.meta_video)
            users, uw = self.meta_user(x[:u], [graph.meta_user])
            x = torch.cat([users, video, x[b:]], dim=0)
        else:
            vw = uw = None
        return x, (vw, uw)

    def forward(self, features, views, offsets):
        state = None
        weights = None
        for snapshot in views:
            x, weights = self._snapshot(features, snapshot, offsets)
            if self.use_temporal:
                state = self.gru(x, state) if state is not None else self.gru(x, torch.zeros_like(x))
            else:
                state = x
        u = state[:self.sizes['user']]
        a = offsets['video']; b = a + self.sizes['video']
        v = state[a:b]
        return {'user': u, 'video': v, 'scope': self.scope_head(v).squeeze(-1),
                'peak': self.peak_head(v).squeeze(-1), 'semantic_weights': weights}

    def rank_scores(self, video_embeddings, user_embeddings, video_ids, user_ids):
        a = video_embeddings[video_ids]
        b = user_embeddings[user_ids]
        return (self.rank_query(a) * self.rank_key(b)).sum(-1) / math.sqrt(a.size(-1)) + self.rank_prior(b).squeeze(-1)

    def rank_matrix(self, video_embeddings, user_embeddings, video_ids):
        """Score all known users at once for a group of video queries."""
        q = self.rank_query(video_embeddings[video_ids])
        k = self.rank_key(user_embeddings)
        bias = self.rank_prior(user_embeddings).squeeze(-1)
        return q @ k.T / math.sqrt(q.size(-1)) + bias.unsqueeze(0)
