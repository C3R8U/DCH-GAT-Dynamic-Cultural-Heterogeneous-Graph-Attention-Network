"""Quick checks for shapes, event timing and model output contracts."""
from pathlib import Path
import sys
import numpy as np
import torch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from dchgat import CulturalDataset
from dchgat.model import segmented_softmax
from dchgat.train import TrainConfig, model_for, phase_views


def dataset():
    return CulturalDataset(ROOT/'data'/'working')


def test_data_integrity():
    d=dataset()
    assert d.n_videos==2582
    assert d.n_users==1200
    assert len(d.labels)==511
    assert set(d.videos.split.unique())=={'train','val','test'}
    assert not d.labels.isna().any().any()
    assert (d.labels.scope>=1).all()


def test_no_future_events_in_graph():
    d=dataset()
    v0=d.graph('train',day=0)
    v1=d.graph('train',day=1)
    assert len(v0.edges['interacts'][0])<=len(v1.edges['interacts'][0])
    train=set(d.split_indices['train'])
    for active in (v0,v1):
        v=active.edges['interacts'][1]-d.offset['video']
        assert set(v.tolist()).issubset(train)
    assert len(d.graph('val',day=0).active_video_indices)==2312


def test_normalized_relation_attention():
    values=torch.tensor([[1.0,2.0],[3.0,0.1],[0.0,2.0],[2.0,-1.0]])
    dst=torch.tensor([0,0,1,1])
    probs=segmented_softmax(values,dst,2)
    for k in (0,1):
        assert torch.allclose(probs[dst==k].sum(0),torch.ones(2),atol=1e-6)


def test_graph_model_shapes():
    d=dataset();cfg=TrainConfig(hidden=32,heads=4,layers=1)
    model=model_for(d,cfg)
    with torch.no_grad():
        output=model(d.features,phase_views(d,'train',cfg),d.offset)
    assert output['video'].shape==(2582,32)
    assert output['scope'].shape==(2582,)
    assert output['user'].shape==(1200,32)
    assert torch.isfinite(output['peak']).all()
