# Measured experimental results

## Independent runs

- Completed seeds: 5
- The clip-level measurements below come from the provided structured archive.
- Confidence intervals over seeds and over test videos answer different questions.

| Metric | Mean | SD | 95% t interval over seeds |
|:---|---:|---:|:---|
| scope_rmse_standardized | 0.8129 | 0.0112 | [0.7990, 0.8269] |
| scope_mae_standardized | 0.7075 | 0.0143 | [0.6897, 0.7252] |
| scope_mae_users | 111.9286 | 2.1750 | [109.2280, 114.6292] |
| peak_mae_days | 0.6841 | 0.0248 | [0.6534, 0.7149] |
| peak_r2 | -0.0140 | 0.0199 | [-0.0387, 0.0107] |
| precision_at_20 | 0.0091 | 0.0034 | [0.0048, 0.0133] |
| recall_at_20 | 0.0091 | 0.0034 | [0.0048, 0.0133] |
| f1_at_20 | 0.0091 | 0.0034 | [0.0048, 0.0133] |

## Tabular baselines

| Name | Reach RMSE | Peak MAE | Rank F1 |
|:---|---:|---:|---:|
| Ridge | 0.5142 | 0.4731 | — |
| SVM | 0.4598 | 0.5364 | — |
| StructuredMLP | 0.5591 | 0.5388 | — |
| RandomForest | 0.1010 | 0.2747 | — |
| FollowerDegree | — | — | 0.1875 |

## Structured-input ablations

| Setting | Reach RMSE | Peak MAE | Rank F1 |
|:---|---:|---:|---:|
| no_attention | 0.8112 | 0.6581 | 0.0094 |
| no_content | 0.8114 | 0.7103 | 0.0117 |
| no_culture_edges | 0.8099 | 0.6253 | 0.0172 |
| no_meta | 0.7989 | 0.7059 | 0.0172 |
| no_temporal | 0.8095 | 0.7343 | 0.0078 |

## Video bootstrap, 1,000 resamples

| Metric | 95% bootstrap interval |
|:---|:---|
| reach_rmse | [0.6869, 0.9181] |
| reach_mae | [0.6046, 0.8003] |
| peak_mae | [0.6229, 0.8246] |
| rank_f1 | [0.0063, 0.0180] |

## Paired held-out comparison against baseline

| Endpoint | Mean difference (graph minus baseline) | Paired t p-value | Wilcoxon p-value |
|:---|---:|---:|---:|
| reach_absolute_error | 0.6241 | 1.38e-18 | 4.26e-12 |
| peak_absolute_error | 0.4095 | 5.87e-11 | 1.76e-09 |
| ranking_f1 | -0.1784 | 3.12e-21 | 3.43e-12 |

Positive error differences indicate worse graph predictions; negative F1 differences indicate worse graph ranking.

## Interpretation

The dataset does not provide raw audio, frames, platform identity, or the external Yelp benchmark.
The reach and peak labels are calculated from sampled cascade events, not platform-wide impressions or daily like counts.
Consequently, these metrics are not directly comparable to values obtained from another dataset.
The video-level top-20 ground truth and predictions have equal cardinality, so precision, recall and F1 coincide by definition.
The labels are limited to observed cascade participants and the static follow graph has no edge timestamps.
Do not interpret these results as a test of causal dissemination mechanisms.
