"""Plots for checking data quality, graph structure and predictive behavior."""
from __future__ import annotations

from collections import Counter
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import networkx as nx

NAVY = '#23395B'
TEAL = '#088F8F'
AMBER = '#D18F27'
RED = '#A23B45'
PURPLE = '#7258A5'


def setup():
    plt.rcParams.update({'font.size': 10, 'axes.spines.top': False, 'axes.spines.right': False,
                         'savefig.dpi': 170, 'axes.titlesize': 13, 'axes.titleweight': 'bold',
                         'figure.facecolor': 'white', 'axes.facecolor': 'white'})


def save(fig, folder, name):
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    fig.savefig(folder / (name + '.png'), bbox_inches='tight')
    if name in ('network_schema', 'architecture'):
        fig.savefig(folder / (name + '.svg'), bbox_inches='tight')
    plt.close(fig)


def plot_data(data, output):
    setup()
    p = Path(output)
    p.mkdir(parents=True, exist_ok=True)
    types = {'Users':data.n_users, 'Videos':data.n_videos, 'Genres':len(data.genres),
             'Cultural tags':len(data.symbols), 'Instruments':len(data.instruments)}
    fig, ax = plt.subplots(figsize=(8.4, 4.4))
    bars = ax.bar(list(types), list(types.values()), color=[NAVY, TEAL, AMBER, PURPLE, RED])
    for b in bars:
        ax.text(b.get_x()+b.get_width()/2, b.get_height()+40, f'{b.get_height():,}', ha='center')
    ax.set_ylim(0, 3450);ax.set_ylabel('Number of nodes');ax.set_title('Heterogeneous node inventory')
    save(fig,p,'node_inventory')

    fig, ax = plt.subplots(figsize=(10,4.6))
    genres = data.videos.genre.value_counts().sort_values()
    ax.barh(genres.index, genres.values, color=TEAL)
    ax.set_xlabel('Videos');ax.set_title('Video genres in the supplied archive')
    for j, c in enumerate(genres): ax.text(c+10, j, str(c), va='center')
    save(fig,p,'genre_distribution')

    frame = data.videos.copy()
    frame['month'] = frame.create_time.dt.to_period('M').astype(str)
    tab = pd.crosstab(frame.month, frame.split).reindex(columns=['train','val','test'],fill_value=0)
    fig,ax=plt.subplots(figsize=(12.5,4.4))
    bottom=np.zeros(len(tab))
    for col,color in (('train',NAVY),('val',TEAL),('test',AMBER)):
        ax.bar(np.arange(len(tab)),tab[col],bottom=bottom,color=color,label=col)
        bottom += tab[col].to_numpy()
    ax.axvline(17.5,color=RED,ls='--',lw=1.5,label='Last in-range month')
    ax.set_xticks(np.arange(len(tab))[::2],tab.index[::2],rotation=35,ha='right')
    ax.set_ylabel('Videos per month');ax.set_title('Publication time and stored data partitions')
    ax.legend(frameon=False,ncol=4)
    save(fig,p,'temporal_split')

    frame=data.labels
    fig,axes=plt.subplots(1,2,figsize=(11,4.1))
    for col,color in (('train',NAVY),('val',TEAL),('test',AMBER)):
        subset=frame[frame.split==col]
        axes[0].hist(subset.scope,bins=18,alpha=.42,label=col,color=color)
    axes[0].set_title('Observed seven-day cascade reach')
    axes[0].set_xlabel('Unique participants'); axes[0].legend(frameon=False)
    peaks=frame.peak_day.value_counts().sort_index()
    axes[1].bar(peaks.index,peaks.values,color=TEAL)
    axes[1].set_title('Peak day of cascade participation');axes[1].set_xlabel('Day after posting')
    axes[1].set_ylabel('Labeled videos')
    save(fig,p,'target_distributions')

    events=data.events
    fig,ax=plt.subplots(figsize=(8,4.2))
    nums=events.day.value_counts().sort_index()
    ax.bar(nums.index.astype(str),nums.values,color=[NAVY,TEAL,AMBER,RED][:len(nums)])
    ax.set_title('Distinct early user-video participation events');ax.set_xlabel('Day since upload')
    ax.set_ylabel('Events available to the model')
    save(fig,p,'early_event_window')

    f = data.tables['edges_user_follow']
    degree = f.dst_user_id.value_counts().to_numpy()
    fig,ax=plt.subplots(figsize=(8,4))
    ax.hist(degree,bins=32,color=NAVY)
    ax.set_title('User follower edge counts');ax.set_xlabel('Observed incoming follow edges')
    ax.set_ylabel('Number of users')
    save(fig,p,'follow_degree')

    fig,ax=plt.subplots(figsize=(11,5.7))
    G=nx.DiGraph()
    labels=['Users','Videos','Genres','Symbols','Instruments']
    pos={'Users':(.05,.55),'Videos':(.47,.55),'Genres':(.88,.91),
         'Symbols':(.88,.56),'Instruments':(.88,.21)}
    G.add_nodes_from(labels)
    for a,b in [('Users','Users'),('Users','Videos'),('Videos','Genres'),
                ('Videos','Symbols'),('Videos','Instruments')]:
        G.add_edge(a,b)
    nx.draw_networkx_nodes(G,pos,ax=ax,nodelist=labels,node_size=[3700,3800,3700,3900,6800],
                           node_color=[NAVY,TEAL,AMBER,PURPLE,RED],alpha=.91)
    nx.draw_networkx_labels(G,pos,ax=ax,font_color='white',font_size=9,font_weight='bold')
    nx.draw_networkx_edges(G,pos,ax=ax,arrows=True,arrowstyle='-|>',arrowsize=20,width=1.9,
                           edge_color='#52657A',connectionstyle='arc3,rad=.10',node_size=3700)
    ax.set_xlim(-.18,1.10);ax.set_ylim(.04,1.06)
    ax.set_title('Five-type cultural heterogeneous network');ax.axis('off')
    save(fig,p,'network_schema')

    # A modest local example is easier to inspect than thousands of overlapping nodes.
    small=data.events.groupby('video_id').size().sort_values(ascending=False).head(6).index.tolist()
    subset=data.events[data.events.video_id.isin(small)].sort_values('days').groupby('video_id').head(4)
    graph=nx.Graph()
    for v in small:
        graph.add_node('V '+v[-5:],kind='video')
        row=data.videos.iloc[data.vid[v]]
        graph.add_node('G '+row.genre,kind='genre')
        graph.add_edge('V '+v[-5:],'G '+row.genre)
    for row in subset.itertuples():
        video='V '+row.video_id[-5:]; user='U '+row.user_id[-5:]
        graph.add_node(user,kind='user');graph.add_edge(video,user)
    fig,ax=plt.subplots(figsize=(11.5,6.6))
    placement=nx.spring_layout(graph,seed=20,k=.68)
    c={'video':TEAL,'genre':AMBER,'user':NAVY}
    nx.draw_networkx(graph,placement,ax=ax,with_labels=True,font_size=7,node_size=500,
                     node_color=[c[graph.nodes[n]['kind']] for n in graph.nodes],font_color='white',
                     edge_color='#CBD6E3',width=1.2)
    ax.set_title('Example early-interaction subgraph with genre links');ax.axis('off')
    save(fig,p,'sample_heterogeneous_graph')

    fig,ax=plt.subplots(figsize=(12.8,5.6))
    ax.set_xlim(0,12);ax.set_ylim(0,5.4);ax.axis('off')
    parts=[(.2,2.5,1.7,1.1,'Node metadata\n+ timed edges',NAVY),
           (2.25,2.5,1.65,1.1,'Relation-aware\nattention',TEAL),
           (4.25,2.5,1.65,1.1,'Two-hop path\nattention',PURPLE),
           (6.26,2.5,1.65,1.1,'Daily states\n+ GRU',AMBER),
           (8.32,3.52,2.5,.68,'Reach regression',NAVY),
           (8.32,2.52,2.5,.68,'Influence ranking',TEAL),
           (8.32,1.52,2.5,.68,'Peak-time regression',RED)]
    for x,y,w,h,label,color in parts:
        rec=plt.Rectangle((x,y),w,h,facecolor=color,edgecolor='white',lw=1.4,alpha=.97)
        ax.add_patch(rec);ax.text(x+w/2,y+h/2,label,ha='center',va='center',color='white',fontsize=10)
    for xa,xb in [(1.9,2.25),(3.9,4.25),(5.9,6.26)]:
        ax.annotate('',xy=(xb,3.05),xytext=(xa,3.05),arrowprops={'arrowstyle':'->','lw':2})
    for y in (3.86,2.86,1.86):
        ax.annotate('',xy=(8.32,y),xytext=(7.91,3.05),arrowprops={'arrowstyle':'->','lw':1.5})
    ax.text(5.45,1.2,'Optional raw-media modules: ResNet-50 for frames; Mel-spectrogram + BiLSTM for audio',
            ha='center',fontsize=10,color=RED)
    ax.text(5.45,.65,'Raw audiovisual files are not included with this archive.',ha='center',fontsize=9,color=RED)
    ax.set_title('Dynamic cultural graph model architecture',fontsize=16)
    save(fig,p,'architecture')


def plot_experiments(data, results_path, output):
    setup()
    p=Path(output);p.mkdir(parents=True,exist_ok=True)
    root=Path(results_path)
    runs=sorted(root.glob('full_seed_*/history.csv'))
    if runs:
        fig,axes=plt.subplots(1,2,figsize=(11,4.2))
        for r in runs:
            frame=pd.read_csv(r)
            label=r.parent.name.replace('full_seed_','Seed ')
            axes[0].plot(frame.epoch,frame.train_loss,lw=1.5,alpha=.7,label=label)
            axes[1].plot(frame.epoch,frame.val_loss,lw=1.5,alpha=.7,label=label)
        axes[0].set_title('Multi-task training loss');axes[1].set_title('Validation loss')
        for ax in axes: ax.set_xlabel('Epoch');ax.set_ylabel('Loss');ax.legend(fontsize=8,frameon=False)
        save(fig,p,'training_curves')
        fig,axes=plt.subplots(1,3,figsize=(13,3.8))
        for r in runs:
            df=pd.read_csv(r);label=r.parent.name.replace('full_seed_','Seed ')
            for ax,name in zip(axes,['val_scope_loss','val_peak_loss','val_rank_loss']):
                ax.plot(df.epoch,df[name],alpha=.65,label=label)
                ax.set_title(name.replace('_',' ').title());ax.set_xlabel('Epoch')
        save(fig,p,'validation_components')
    preds=sorted(root.glob('full_seed_*/test_predictions.csv'))
    if preds:
        df=pd.read_csv(preds[0]); outlier=max(df.scope.max(), df.scope_pred.max())
        fig,ax=plt.subplots(figsize=(6.5,6.2))
        ax.scatter(df.scope,df.scope_pred,alpha=.56,s=24,c=TEAL,edgecolors='none')
        ax.plot([0,outlier],[0,outlier],ls='--',c=RED)
        ax.set_xlabel('Observed unique participants');ax.set_ylabel('Predicted participants')
        ax.set_title('Held-out seven-day reach')
        save(fig,p,'scope_scatter')
        fig,axes=plt.subplots(1,2,figsize=(11,4.4))
        residual=df.scope_pred-df.scope
        axes[0].scatter(df.scope,residual,alpha=.5,c=NAVY,s=22)
        axes[0].axhline(0,c=RED,ls='--');axes[0].set_title('Reach residuals')
        axes[0].set_xlabel('Observed participants');axes[0].set_ylabel('Predicted - observed')
        axes[1].hist(residual,bins=25,color=TEAL)
        axes[1].set_title('Reach residual distribution');axes[1].set_xlabel('Error in users')
        save(fig,p,'scope_residuals')
        fig,axes=plt.subplots(1,2,figsize=(11,4.3))
        axes[0].scatter(df.peak_day,df.peak_pred,s=25,alpha=.5,c=TEAL)
        axes[0].plot([0,4],[0,4],'--',c=RED)
        axes[0].set_xlabel('Observed peak day');axes[0].set_ylabel('Predicted peak day')
        axes[0].set_title('Held-out participation peak')
        axes[1].hist(df.peak_pred-df.peak_day,bins=20,color=AMBER)
        axes[1].set_title('Peak-time residuals');axes[1].set_xlabel('Predicted - observed days')
        save(fig,p,'peak_prediction')
        hist=np.zeros((5,5),dtype=int)
        for obs,pred in zip(df.peak_day,df.peak_pred):
            hist[int(np.clip(obs,0,4)),int(np.clip(round(pred),0,4))]+=1
        fig,ax=plt.subplots(figsize=(6,5))
        image=ax.imshow(hist,cmap='Blues')
        for i in range(5):
            for j in range(5): ax.text(j,i,str(hist[i,j]),ha='center',va='center',fontsize=9)
        ax.set_xticks(range(5));ax.set_yticks(range(5));ax.set_xlabel('Rounded prediction (day)')
        ax.set_ylabel('Observed peak (day)');ax.set_title('Peak-day confusion matrix')
        fig.colorbar(image,ax=ax,label='Videos');save(fig,p,'peak_confusion')
        fig,ax=plt.subplots(figsize=(8,4.4))
        ax.hist(df.f1_at_20.dropna(),bins=np.linspace(0,1,21),color=PURPLE)
        ax.set_title('Held-out influential-user ranking');ax.set_xlabel('Top-20 precision / recall / F1')
        ax.set_ylabel('Videos');save(fig,p,'rank_overlap')
    summaries=[]
    for m in root.glob('full_seed_*/metrics.json'):
        x=json.loads(m.read_text());summaries.append(x['test'])
    base_path=root/'baselines'/'baseline_metrics.json'
    if summaries and base_path.exists():
        baselines=json.loads(base_path.read_text())
        lab=['DCH-GAT']+[x for x in baselines if 'scope_rmse_standardized' in baselines[x]]
        vals=[np.mean([x['scope_rmse_standardized'] for x in summaries])]+[
            baselines[x]['scope_rmse_standardized'] for x in lab[1:]]
        fig,ax=plt.subplots(figsize=(8,4.5))
        ax.bar(lab,vals,color=[TEAL,NAVY,AMBER]);ax.set_ylabel('RMSE (training-standardized log reach)')
        ax.set_title('Measured test error, supplied dataset')
        for j,v in enumerate(vals):ax.text(j,v+0.008,f'{v:.3f}',ha='center')
        ax.set_ylim(0,max(vals)*1.2);save(fig,p,'model_comparison')
    if summaries:
        names=['scope_rmse_standardized','peak_mae_days','f1_at_20']
        vals=[np.array([x[n] for x in summaries]) for n in names]
        fig,axes=plt.subplots(1,3,figsize=(11.5,4))
        for ax,key,v in zip(axes,names,vals):
            ax.scatter(np.ones(len(v)),v,color=TEAL,alpha=.75,s=42)
            ax.errorbar([1],[v.mean()],yerr=[v.std(ddof=1) if len(v)>1 else 0],
                        fmt='s',color=RED,capsize=6,markersize=7)
            ax.set_xlim(.5,1.5);ax.set_xticks([]);ax.set_title(key.replace('_',' ').title())
        fig.suptitle('Across independent random seeds')
        save(fig,p,'seed_variation')
    ab=[]
    for m in root.glob('ablation_*/metrics.json'):
        x=json.loads(m.read_text());ab.append((m.parent.name.replace('ablation_',''),x['test']))
    if ab and summaries:
        labels=['full']+[i for i,_ in ab]
        rm=[summaries[0]['scope_rmse_standardized']]+[x['scope_rmse_standardized'] for _,x in ab]
        f1=[summaries[0]['f1_at_20']]+[x['f1_at_20'] for _,x in ab]
        fig,axes=plt.subplots(1,2,figsize=(12,4.6))
        for ax,vals,title in zip(axes,[rm,f1],['Reach RMSE (lower is better)','Top-20 F1 (higher is better)']):
            ax.barh(labels,vals,color=[TEAL]+[NAVY]*(len(labels)-1));ax.invert_yaxis();ax.set_title(title)
        fig.suptitle('Structured-input component ablations (single seed)')
        save(fig,p,'component_ablations')
