#!/usr/bin/env python3
"""Summarize reference integrity and timestamp coverage before graph fitting."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
TABLE_NAMES = ('users', 'videos', 'music', 'video_tags', 'video_music',
               'video_split', 'edges_user_follow', 'edges_user_interactions', 'cascades')


def audit(folder: Path) -> dict:
    frames = {name: pd.read_csv(folder / f'{name}.csv') for name in TABLE_NAMES}
    v = frames['videos']
    users = set(frames['users'].user_id)
    videos = set(v.video_id)
    music = set(frames['music'].music_id)
    tags = frames['video_tags']
    interactions = frames['edges_user_interactions']
    cascades = frames['cascades']
    follow = frames['edges_user_follow']
    publication = v.set_index('video_id').create_time.pipe(pd.to_datetime)
    result = {'row_counts': {name: int(len(df)) for name, df in frames.items()},
              'missing_cell_counts': {name: int(df.isna().sum().sum()) for name, df in frames.items()},
              'duplicate_video_ids': int(v.video_id.duplicated().sum()),
              'duplicate_user_ids': int(frames['users'].user_id.duplicated().sum()),
              'unmatched_video_references': {}, 'unmatched_user_references': {},
              'unmatched_music_references': int((~frames['video_music'].music_id.isin(music)).sum()),
              'unique_cascade_videos': int(cascades.video_id.nunique()),
              'video_count_without_cascade': int(len(videos - set(cascades.video_id))),
              'split_count': frames['video_split'].split.value_counts().to_dict()}
    for key in ('video_tags', 'video_music', 'video_split',
                'edges_user_interactions', 'cascades'):
        result['unmatched_video_references'][key] = int((~frames[key].video_id.isin(videos)).sum())
    for key, col in (('edges_user_follow', 'src_user_id'),
                     ('edges_user_interactions', 'user_id'), ('cascades', 'user_id')):
        result['unmatched_user_references'][key] = int((~frames[key][col].isin(users)).sum())
    result['unmatched_user_references']['edges_user_follow_dst'] = int((~follow.dst_user_id.isin(users)).sum())
    result['unmatched_user_references']['video_author'] = int((~v.author_id.isin(users)).sum())

    # The label window starts at publication and ends seven days later.
    for name, table in (('cascades', cascades), ('edges_user_interactions', interactions)):
        timestamp = pd.to_datetime(table.timestamp)
        delta = (timestamp - pd.to_datetime(table.video_id.map(publication))).dt.total_seconds() / 86400
        result[f'{name}_days_after_publication'] = {
            'minimum': float(delta.min()), 'median': float(delta.median()),
            'maximum': float(delta.max()),
            'negative_count': int((delta < 0).sum()),
            'days_7_or_more': int((delta >= 7).sum()),
            'within_2_days': int(((delta >= 0) & (delta < 2)).sum())}
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data', type=Path, default=ROOT / 'data' / 'working')
    parser.add_argument('--output', type=Path,
                        default=ROOT / 'outputs' / 'preprocessing' / 'data_quality.json')
    args = parser.parse_args()
    result = audit(args.data)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
