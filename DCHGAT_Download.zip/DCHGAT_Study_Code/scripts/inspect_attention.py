#!/usr/bin/env python3
"""Inspect learned semantic-path weights for held-out diffusion videos."""
from __future__ import annotations

import argparse
from pathlib import Path
import sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import torch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from dchgat import CulturalDataset
from dchgat.train import TrainConfig, model_for, phase_views


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,default=ROOT/'outputs')
    parser.add_argument('--data',type=Path,default=ROOT/'data'/'working')
    parser.add_argument('--seed',type=int,default=2021)
    args=parser.parse_args()
    saved=args.output/f'full_seed_{args.seed}'/'best_model.pt'
    d=CulturalDataset(args.data)
    state=torch.load(saved,map_location='cpu',weights_only=True)
    cfg=TrainConfig(**state['config'])
    model=model_for(d,cfg)
    model.load_state_dict(state['model_state']);model.eval()
    with torch.no_grad():
        out=model(d.features,phase_views(d,'test',cfg),d.offset)
    if out['semantic_weights'][0] is None:
        raise ValueError('Semantic-path attention is disabled in this checkpoint.')
    names=['Self','Genre','Instrument','Cultural symbol','Shared users']
    clips=d.labels[d.labels.split=='test'].copy()
    weights=out['semantic_weights'][0][clips.video_ix.to_numpy()].cpu().numpy()
    report=pd.DataFrame(weights,columns=names)
    report.insert(0,'video_id',clips.video_id.to_numpy())
    report.to_csv(args.output/'semantic_path_weights.csv',index=False)
    mean=weights.mean(axis=0)
    fig,ax=plt.subplots(figsize=(9,4.1))
    ax.bar(names,mean,color=['#23395B','#D18F27','#A23B45','#7258A5','#088F8F'])
    ax.set_ylim(0,max(mean)*1.2)
    ax.set_ylabel('Mean semantic attention weight')
    ax.set_title('Learned path importance on held-out videos')
    for k,val in enumerate(mean):ax.text(k,val+.004,f'{val:.3f}',ha='center')
    fig.tight_layout();fig.savefig(args.output/'figures'/'path_attention_mean.png',dpi=170);plt.close(fig)
    keep=np.argsort(-clips.scope.to_numpy())[:35]
    fig,ax=plt.subplots(figsize=(10,8))
    image=ax.imshow(weights[keep],cmap='viridis',aspect='auto',vmin=0,vmax=max(.3,weights.max()))
    ax.set_xticks(range(len(names)),names,rotation=20,ha='right')
    ax.set_yticks(range(len(keep)),clips.video_id.iloc[keep].str[-6:].to_numpy(),fontsize=7)
    ax.set_title('Per-video semantic attention: top observed cascades')
    fig.colorbar(image,ax=ax,label='Attention weight')
    fig.tight_layout();fig.savefig(args.output/'figures'/'path_attention_heatmap.png',dpi=170);plt.close(fig)
    print('Saved semantic-path attention tables and figures')


if __name__=='__main__':
    main()
