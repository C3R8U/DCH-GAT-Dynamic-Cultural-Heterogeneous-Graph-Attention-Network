#!/usr/bin/env python3
"""Aggregate measured seed results and inspect uncertainty on held-out clips."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
import numpy as np
import pandas as pd
from scipy import stats

ROOT=Path(__file__).resolve().parents[1]
FIELDS=['scope_rmse_standardized','scope_mae_standardized','scope_mae_users',
        'peak_mae_days','peak_r2','precision_at_20','recall_at_20','f1_at_20']


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--output',type=Path,default=ROOT/'outputs')
    args=p.parse_args()
    root=args.output
    runs=[]
    for file in sorted(root.glob('full_seed_*/metrics.json')):
        metrics=json.loads(file.read_text())
        runs.append({'seed':metrics['seed'],'best_epoch':metrics['best_epoch'],
                     'epochs_completed':metrics['epochs_completed'],**metrics['test']})
    if not runs:
        print('No finished runs found.')
        return
    frame=pd.DataFrame(runs)
    frame.to_csv(root/'seed_metrics.csv',index=False)
    interval={}
    for key in FIELDS:
        x=frame[key].to_numpy(dtype=float)
        ci=stats.t.interval(.95,len(x)-1,loc=x.mean(),scale=stats.sem(x)) if len(x)>1 else (None,None)
        interval[key]={'mean':float(x.mean()),'sd':float(np.std(x,ddof=1)) if len(x)>1 else None,
                       'ci95_seed_t':[float(v) for v in ci] if len(x)>1 else None}
    (root/'seed_summary.json').write_text(json.dumps(interval,indent=2))
    # Sampling videos with replacement quantifies test-set uncertainty for the first completed seed.
    first=sorted(root.glob('full_seed_*/test_predictions.csv'))[0]
    df=pd.read_csv(first)
    rng=np.random.default_rng(22026)
    samples={k:[] for k in ('reach_rmse','reach_mae','peak_mae','rank_f1')}
    for _ in range(1000):
        a=df.iloc[rng.integers(0,len(df),size=len(df))]
        e=(a.z_scope-a.z_pred).to_numpy()
        samples['reach_rmse'].append(float(np.sqrt((e*e).mean())))
        samples['reach_mae'].append(float(np.abs(e).mean()))
        samples['peak_mae'].append(float(np.abs(a.peak_day-a.peak_pred).mean()))
        samples['rank_f1'].append(float(a.f1_at_20.mean()))
    boot={k:{'lower':float(np.percentile(v,2.5)), 'upper':float(np.percentile(v,97.5))}
          for k,v in samples.items()}
    (root/'bootstrap_1000_ci.json').write_text(json.dumps(boot,indent=2))
    abl=[]
    for path in sorted(root.glob('ablation_*/metrics.json')):
        x=json.loads(path.read_text())
        abl.append({'configuration':path.parent.name.replace('ablation_',''),
                    **x['test'],'epochs_completed':x['epochs_completed']})
    if abl:
        pd.DataFrame(abl).to_csv(root/'ablation_metrics.csv',index=False)
    baselines=json.loads((root/'baselines'/'baseline_metrics.json').read_text())
    lines=['# Measured experimental results','','## Independent runs',
           '', f'- Completed seeds: {len(runs)}',
           '- The clip-level measurements below come from the provided structured archive.',
           '- Confidence intervals over seeds and over test videos answer different questions.','',
           '| Metric | Mean | SD | 95% t interval over seeds |',
           '|:---|---:|---:|:---|']
    for key in FIELDS:
        x=interval[key]; ci=x['ci95_seed_t']
        ci_text=f"[{ci[0]:.4f}, {ci[1]:.4f}]" if ci else 'Not available'
        lines.append(f"| {key} | {x['mean']:.4f} | {x['sd']:.4f} | {ci_text} |" if x['sd'] is not None
                     else f"| {key} | {x['mean']:.4f} | N/A | {ci_text} |")
    lines += ['', '## Tabular baselines','','| Name | Reach RMSE | Peak MAE | Rank F1 |',
              '|:---|---:|---:|---:|']
    for name,record in baselines.items():
        fm=lambda k: f"{record[k]:.4f}" if k in record else '—'
        lines.append(f"| {name} | {fm('scope_rmse_standardized')} | {fm('peak_mae_days')} | {fm('f1_at_20')} |")
    if abl:
        lines += ['', '## Structured-input ablations',
                  '', '| Setting | Reach RMSE | Peak MAE | Rank F1 |',
                  '|:---|---:|---:|---:|']
        for row in abl:
            lines.append(f"| {row['configuration']} | {row['scope_rmse_standardized']:.4f} | "
                         f"{row['peak_mae_days']:.4f} | {row['f1_at_20']:.4f} |")
    lines += ['', '## Video bootstrap, 1,000 resamples','','| Metric | 95% bootstrap interval |',
              '|:---|:---|']
    for key,ci in boot.items():
        lines.append(f"| {key} | [{ci['lower']:.4f}, {ci['upper']:.4f}] |")
    comparison_file=root/'paired_comparisons.json'
    if comparison_file.exists():
        comparisons=json.loads(comparison_file.read_text())
        lines += ['', '## Paired held-out comparison against baseline',
                  '', '| Endpoint | Mean difference (graph minus baseline) | Paired t p-value | Wilcoxon p-value |',
                  '|:---|---:|---:|---:|']
        for name,row in comparisons.items():
            lines.append(f"| {name} | {row['mean_difference']:.4f} | {row['p_paired_t']:.3g} | {row['p_wilcoxon']:.3g} |")
        lines += ['', 'Positive error differences indicate worse graph predictions; negative F1 differences indicate worse graph ranking.']
    lines += ['', '## Interpretation',
              '', 'The dataset does not provide raw audio, frames, platform identity, or the external Yelp benchmark.',
              'The reach and peak labels are calculated from sampled cascade events, not platform-wide impressions or daily like counts.',
              'Consequently, these metrics are not directly comparable to values obtained from another dataset.',
              'The video-level top-20 ground truth and predictions have equal cardinality, so precision, recall and F1 coincide by definition.',
              'The labels are limited to observed cascade participants and the static follow graph has no edge timestamps.',
              'Do not interpret these results as a test of causal dissemination mechanisms.','']
    (root/'RESULTS.md').write_text('\n'.join(lines),encoding='utf-8')
    print('Saved result tables, bootstrap intervals and RESULTS.md')


if __name__=='__main__':
    main()
