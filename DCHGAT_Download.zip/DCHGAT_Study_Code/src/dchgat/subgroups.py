"""Held-out group diagnostics and controlled changes to cultural metadata."""
from __future__ import annotations

from collections import Counter
from pathlib import Path
import json
import numpy as np
import pandas as pd
import torch
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

from .train import TrainConfig, evaluate, model_for


def _summarize(group):
    delta = group.z_scope.to_numpy() - group.z_pred.to_numpy()
    return {'n':len(group),
            'scope_rmse_standardized': float(np.sqrt(np.mean(delta**2))),
            'scope_mae_standardized': float(np.mean(np.abs(delta))),
            'peak_mae_days':float(mean_absolute_error(group.peak_day,group.peak_pred)),
            'f1_at_20':float(group.f1_at_20.mean())}


def evaluate_groups(data, predictions, output):
    root=Path(output);root.mkdir(parents=True,exist_ok=True)
    p=pd.read_csv(predictions)
    d=data.videos[['video_id','genre','instrument','region','author_id','create_time']]
    p=p.merge(d,on='video_id',how='left',validate='one_to_one')
    e=data.events[data.events.video_ix.isin(data.split_indices['train'])]
    history=e.user_ix.value_counts()
    authors=data.videos.author_id.map(data.uid)
    counts=authors.map(history).fillna(0).astype(int)
    p['author_history_events']=p.video_ix.map(pd.Series(counts.to_numpy()))
    p['month']=pd.to_datetime(p.create_time).dt.to_period('M').astype(str)
    p['quarter']=pd.to_datetime(p.create_time).dt.to_period('Q').astype(str)
    p['creator_history_bucket']=pd.cut(p.author_history_events,
                                       bins=[-1,0,2,4,9,float('inf')],
                                       labels=['0','1-2','3-4','5-9','10+'])
    r=[]
    for field in ('genre','instrument','region','quarter','creator_history_bucket'):
        for value,group in p.groupby(field,observed=True):
            if len(group)>=5:
                r.append({'grouping':field,'group':str(value),**_summarize(group)})
    r=pd.DataFrame(r)
    r.to_csv(root/'group_metrics.csv',index=False)
    thresholds=[]
    for n in (0,3,5,10,30,40,50):
        subset=p[p.author_history_events==0] if n==0 else p[p.author_history_events<n]
        heading=str(n) if n==0 else f'<{n}'
        if len(subset):
            thresholds.append({'historical_early_interaction_count':heading,
                               'status':'measured',**_summarize(subset)})
        else:
            thresholds.append({'historical_early_interaction_count':heading,
                               'status':'no_eligible_videos','n':0,
                               'scope_rmse_standardized':np.nan,
                               'scope_mae_standardized':np.nan,
                               'peak_mae_days':np.nan,'f1_at_20':np.nan})
    pd.DataFrame(thresholds).to_csv(root/'creator_coldstart.csv',index=False)
    p.to_csv(root/'test_annotated.csv',index=False)
    return r


@torch.no_grad()
def metadata_perturbation(data, checkpoint, output, repeats=10, seed=2021):
    root=Path(output);root.mkdir(parents=True,exist_ok=True)
    state=torch.load(checkpoint,map_location='cpu',weights_only=True)
    config=TrainConfig(**state['config'])
    model=model_for(data,config).eval()
    model.load_state_dict(state['model_state'])
    baseline,_=evaluate(data,model,'test',config)
    rng=np.random.default_rng(seed)
    base=data.features['video']
    index=data.split_indices['test']
    months=data.videos.iloc[index].create_time.dt.to_period('M').astype(str).to_numpy()
    monthly=[index[months==m] for m in sorted(set(months))]
    rows=[]
    for key in ('genre','instrument'):
        left,right=data.video_metadata_slices[key]
        for rep in range(repeats):
            changed=base.clone()
            for clip_indices in monthly:
                shuffled=rng.permutation(clip_indices)
                changed[clip_indices,left:right]=base[shuffled,left:right]
            data.features['video']=changed
            measured=evaluate(data,model,'test',config,include_predictions=False)
            rows.append({'feature':key,'repetition':rep+1,
                         'scope_rmse_delta':measured['scope_rmse_standardized']-baseline['scope_rmse_standardized'],
                         'peak_mae_delta':measured['peak_mae_days']-baseline['peak_mae_days'],
                         'rank_f1_delta':measured['f1_at_20']-baseline['f1_at_20']})
    data.features['video']=base
    result=pd.DataFrame(rows)
    result.to_csv(root/'metadata_perturbation.csv',index=False)
    (root/'reference_test_metrics.json').write_text(json.dumps(baseline,indent=2))
    return result
