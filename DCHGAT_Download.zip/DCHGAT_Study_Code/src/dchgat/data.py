"""Structured cultural graph data, chronological windows and diffusion targets."""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List
import json

import numpy as np
import pandas as pd
import torch
from scipy import sparse
from sklearn.feature_extraction.text import HashingVectorizer

NODE_TYPES = ("user", "video", "genre", "symbol", "instrument")
RELATIONS = (
    "follows", "followed_by", "published", "published_by", "interacts", "interacted_by",
    "has_genre", "genre_of", "has_symbol", "symbol_of", "has_instrument", "instrument_of",
)


def _date(s):
    return pd.to_datetime(s, errors="coerce", utc=True).dt.tz_localize(None)


def _matrix(cats: Dict[str, pd.Series], numerical: Dict[str, np.ndarray] | None = None):
    frames = [pd.get_dummies(v.fillna("unknown").astype(str), prefix=k, dtype=float) for k, v in cats.items()]
    if numerical:
        frames.extend(pd.DataFrame({name: np.asarray(vec, dtype=float)}) for name, vec in numerical.items())
    if not frames:
        return np.zeros((len(next(iter(cats.values()))), 1), dtype=np.float32)
    return pd.concat(frames, axis=1).fillna(0).to_numpy(dtype=np.float32)


def _meta_graph(groups: List[List[int]], n: int, cap: int = 12, seed: int = 17):
    """Link entities that share an attribute without constructing giant dense cliques."""
    rng = np.random.default_rng(seed)
    near = defaultdict(set)
    for ids in groups:
        ids = list(dict.fromkeys(ids))
        for src in ids:
            if len(ids) <= cap + 1:
                neighbors = ids
            else:
                indices = rng.choice(len(ids), size=min(cap + 1, len(ids)), replace=False)
                neighbors = [ids[i] for i in indices]
            near[src].update(j for j in neighbors if j != src)
    rows, cols = [], []
    for i, nbs in near.items():
        for j in sorted(nbs)[:cap]:
            rows.append(i)
            cols.append(j)
    if not rows:
        return torch.sparse_coo_tensor(torch.zeros((2, 0), dtype=torch.long),
                                       torch.empty(0), (n, n)).coalesce()
    degree = np.bincount(rows, minlength=n).clip(min=1)
    w = (1.0 / degree[np.asarray(rows)]).astype(np.float32)
    return torch.sparse_coo_tensor(torch.tensor([rows, cols], dtype=torch.long),
                                   torch.tensor(w), (n, n)).coalesce()


@dataclass
class GraphView:
    edges: Dict[str, tuple[torch.Tensor, torch.Tensor]]
    meta_video: List[torch.Tensor]
    meta_user: torch.Tensor
    active_video_indices: torch.Tensor


class CulturalDataset:
    def __init__(self, directory: str | Path, observation_days: int = 2,
                 media_features: str | Path | None = None):
        self.path = Path(directory)
        files = ("users", "music", "videos", "video_tags", "video_music", "video_split",
                 "edges_user_follow", "edges_user_interactions", "cascades")
        self.tables = {f: pd.read_csv(self.path / (f + ".csv")) for f in files}
        self.users = self.tables["users"].reset_index(drop=True)
        self.videos = self.tables["videos"].reset_index(drop=True)
        self.videos["create_time"] = _date(self.videos["create_time"])
        self.users["join_time"] = _date(self.users["join_time"])
        self.n_users, self.n_videos = len(self.users), len(self.videos)
        self.uid = {x: i for i, x in enumerate(self.users.user_id)}
        self.vid = {x: i for i, x in enumerate(self.videos.video_id)}
        self.genres = sorted(self.videos.genre.astype(str).unique())
        self.symbols = sorted(self.tables["video_tags"].tag.astype(str).unique())
        self.instruments = sorted(self.videos.instrument.astype(str).unique())
        self.gid = {x: i for i, x in enumerate(self.genres)}
        self.sid = {x: i for i, x in enumerate(self.symbols)}
        self.iid = {x: i for i, x in enumerate(self.instruments)}
        self.sizes = {"user": self.n_users, "video": self.n_videos,
                      "genre": len(self.genres), "symbol": len(self.symbols),
                      "instrument": len(self.instruments)}
        cursor = 0
        self.offset = {}
        for typ in NODE_TYPES:
            self.offset[typ] = cursor
            cursor += self.sizes[typ]
        self.n_nodes = cursor
        split = self.tables["video_split"].set_index("video_id").split
        self.videos["split"] = self.videos.video_id.map(split)
        if self.videos.split.isna().any():
            raise ValueError("Every video needs an explicit split.")
        self.split_indices = {name: np.flatnonzero(self.videos.split.eq(name).to_numpy())
                              for name in ("train", "val", "test")}
        self.observation_days = observation_days
        self.media_feature_path = Path(media_features) if media_features else None
        self.media_slices = {}
        self.features = self._features()
        self.events = self._events()
        self.labels, self.rank_targets = self._labels()
        self.views = {}

    def _features(self):
        # Follower counts are intentionally excluded: their historical observation dates are unknown.
        u = _matrix({"account": self.users.account_type, "region": self.users.region})
        ms = self.tables["music"].set_index("music_id")
        music = self.videos.music_id.map(ms["mode"]).fillna("unknown")
        tempo = self.videos.music_id.map(ms["tempo_bpm"]).fillna(ms.tempo_bpm.median()).to_numpy()
        tempo = (tempo - np.mean(tempo[self.split_indices["train"]])) / (np.std(tempo[self.split_indices["train"]]) + 1e-6)
        self.video_metadata_slices = {}
        cursor = 0
        for key, values in (("genre", self.videos.genre), ("instrument", self.videos.instrument),
                            ("region", self.videos.region), ("dialect", self.videos.dialect),
                            ("mode", music)):
            width = int(values.fillna('unknown').astype(str).nunique())
            self.video_metadata_slices[key] = [cursor, cursor + width]
            cursor += width
        v_cat = _matrix({"genre": self.videos.genre, "instrument": self.videos.instrument,
                         "region": self.videos.region, "dialect": self.videos.dialect,
                         "mode": music},
                        {"tempo": tempo,
                         "description_length": self.videos.description.astype(str).str.len().to_numpy() / 150.0})
        hash_v = HashingVectorizer(n_features=32, alternate_sign=False, norm="l2").transform(
            self.videos.description.fillna("").astype(str))
        v = np.hstack([v_cat, hash_v.toarray().astype(np.float32)]).astype(np.float32)
        if self.media_feature_path is not None:
            # Only attach audiovisual descriptors when every row has a real extracted feature.
            archive = np.load(self.media_feature_path, allow_pickle=False)
            actual = archive["video_id"].astype(str).tolist()
            expected = self.videos.video_id.astype(str).tolist()
            if actual != expected:
                raise ValueError("Audio/visual feature IDs must exactly match videos.csv order.")
            for name in ("visual", "audio"):
                data = np.asarray(archive[name], dtype=np.float32)
                if len(data) != self.n_videos or data.ndim != 2 or not np.isfinite(data).all():
                    raise ValueError(f"Invalid {name} descriptor matrix.")
                start = v.shape[1]
                v = np.hstack([v, data])
                self.media_slices[name] = [start, v.shape[1]]
        return {
            "user": torch.from_numpy(u), "video": torch.from_numpy(v),
            "genre": torch.eye(len(self.genres)),
            "symbol": torch.eye(len(self.symbols)),
            "instrument": torch.eye(len(self.instruments)),
        }

    def _events(self):
        # The first participation of a user in a video is sufficient for the input graph.
        vtime = self.videos.set_index("video_id").create_time
        author = self.videos.set_index("video_id").author_id
        cascade = self.tables["cascades"][['video_id', 'user_id', 'timestamp']].copy()
        external = self.tables["edges_user_interactions"][['video_id', 'user_id', 'timestamp']].copy()
        e = pd.concat([cascade, external], ignore_index=True)
        e["timestamp"] = _date(e.timestamp)
        e["posted"] = e.video_id.map(vtime)
        e["days"] = (e.timestamp - e.posted).dt.total_seconds() / 86400
        e = e[(e.days >= 0) & (e.days < self.observation_days) & (e.user_id != e.video_id.map(author))].copy()
        e = e[e.video_id.isin(self.vid) & e.user_id.isin(self.uid)]
        e = e.sort_values("timestamp").drop_duplicates(["video_id", "user_id"])
        e["video_ix"] = e.video_id.map(self.vid).astype(int)
        e["user_ix"] = e.user_id.map(self.uid).astype(int)
        e["day"] = np.floor(e.days).astype(int)
        return e

    def _labels(self):
        c = self.tables["cascades"].copy()
        c["timestamp"] = _date(c.timestamp)
        vtime = self.videos.set_index("video_id").create_time
        c["delta"] = (c.timestamp - c.video_id.map(vtime)).dt.total_seconds() / 86400
        c = c[(c.delta >= 0) & (c.delta < 7) & (c.layer > 0)].copy()
        c = c.sort_values('timestamp').drop_duplicates(['video_id', 'user_id'])
        c["day"] = np.floor(c.delta).astype(int)

        # These follower links let us estimate which participants had later reachable peers.
        follows = self.tables["edges_user_follow"]
        followers = defaultdict(set)
        for a, b in zip(follows.src_user_id, follows.dst_user_id):
            followers[b].add(a)
        rows = []
        top = {}
        for video, group in c.groupby("video_id", sort=False):
            ix = self.vid[video]
            moment = dict(zip(group.user_id, group.delta))
            counts = group.groupby("day").size()
            peak = int(counts.idxmax())
            influence = {}
            for user, start in moment.items():
                later = [moment[w] - start for w in followers[user]
                         if w in moment and moment[w] > start]
                influence[user] = float(np.exp(-0.3 * np.asarray(later)).sum()) if later else 0.0
            # Top-20 is drawn only from observed participants; remaining users stay candidates at evaluation.
            top_users = sorted(influence, key=lambda x: (-influence[x], x))[:20]
            top[ix] = np.asarray([self.uid[u] for u in top_users], dtype=np.int64)
            rows.append({"video_ix": ix, "video_id": video, "scope": len(moment),
                         "peak_day": peak, "participants": len(moment),
                         "split": self.videos.iloc[ix].split})
        label = pd.DataFrame(rows).sort_values("video_ix").reset_index(drop=True)
        label["log_scope"] = np.log1p(label.scope)
        tr = label[label.split == "train"].log_scope.to_numpy()
        self.scope_mean = float(tr.mean())
        self.scope_std = float(tr.std() + 1e-6)
        label["z_scope"] = (label.log_scope - self.scope_mean) / self.scope_std
        return label, top

    def _edge(self, a, b, mask=None):
        if mask is not None:
            a, b = a[mask], b[mask]
        return torch.as_tensor(a, dtype=torch.long), torch.as_tensor(b, dtype=torch.long)

    def graph(self, phase: str, day: int = 1, include_culture: bool = True):
        """Only expose early interactions and cultural attributes from the current evaluation period."""
        key = (phase, day, include_culture)
        if key in self.views:
            return self.views[key]
        groups = {"train": ["train"], "val": ["train", "val"],
                  "test": ["train", "val", "test"]}
        active = self.videos.split.isin(groups[phase]).to_numpy()
        active_indices = np.flatnonzero(active)
        offset = self.offset
        edges = {}
        def add(name, aa, bb):
            edges[name] = self._edge(aa, bb)
        f = self.tables["edges_user_follow"]
        fa = f.src_user_id.map(self.uid).to_numpy(dtype=int) + offset['user']
        fb = f.dst_user_id.map(self.uid).to_numpy(dtype=int) + offset['user']
        add('follows', fa, fb)
        add('followed_by', fb, fa)
        vi = active_indices + offset['video']
        au = self.videos.loc[active, 'author_id'].map(self.uid).to_numpy(dtype=int) + offset['user']
        add('published', au, vi)
        add('published_by', vi, au)
        ev = self.events[(self.events.video_ix.isin(active_indices)) & (self.events.day <= day)]
        eu = ev.user_ix.to_numpy(dtype=int) + offset['user']
        evv = ev.video_ix.to_numpy(dtype=int) + offset['video']
        add('interacts', eu, evv)
        add('interacted_by', evv, eu)
        if include_culture:
            gg = self.videos.loc[active, 'genre'].map(self.gid).to_numpy(dtype=int) + offset['genre']
            ii = self.videos.loc[active, 'instrument'].map(self.iid).to_numpy(dtype=int) + offset['instrument']
            tags = self.tables['video_tags']
            tag_ix = tags.video_id.map(self.vid)
            m = tag_ix.isin(active_indices)
            tv = tag_ix[m].to_numpy(dtype=int) + offset['video']
            ts = tags.loc[m, 'tag'].map(self.sid).to_numpy(dtype=int) + offset['symbol']
            for x, r, n, rev in ((vi, gg, 'has_genre', 'genre_of'),
                                  (vi, ii, 'has_instrument', 'instrument_of'),
                                  (tv, ts, 'has_symbol', 'symbol_of')):
                add(n, x, r)
                add(rev, r, x)
        # Two-step semantic routes: video-attribute-video and video-user-video.
        group_by = lambda pairs: list(pairs.values())
        sets = []
        for kind in ('genre', 'instrument'):
            gp = defaultdict(list)
            for ix in active_indices:
                gp[str(self.videos.iloc[ix][kind])].append(ix)
            sets.append(group_by(gp))
        gp = defaultdict(list)
        for row in self.tables['video_tags'].itertuples(index=False):
            ix = self.vid.get(row.video_id)
            if ix is not None and active[ix]:
                gp[row.tag].append(ix)
        sets.append(group_by(gp))
        gp = defaultdict(list)
        for v, uid in zip(ev.video_ix, ev.user_ix):
            gp[int(uid)].append(int(v))
        sets.append(group_by(gp))
        if not include_culture:
            sets[:3] = [[], [], []]
        meta_video = [_meta_graph(gr, self.n_videos, seed=19 + n) for n, gr in enumerate(sets)]
        gp2 = defaultdict(list)
        for v, uid in zip(ev.video_ix, ev.user_ix):
            gp2[int(v)].append(int(uid))
        meta_user = _meta_graph(group_by(gp2), self.n_users, seed=31)
        out = GraphView(edges, meta_video, meta_user, torch.as_tensor(active_indices, dtype=torch.long))
        self.views[key] = out
        return out

    def audit(self):
        v = self.videos
        sp = self.tables['video_split'].merge(v[['video_id','create_time']], on='video_id')
        interaction = self.tables['edges_user_interactions']
        return {
            'files': {k: {'rows': int(len(df)), 'columns': list(df.columns)} for k, df in self.tables.items()},
            'node_types': self.sizes,
            'videos_by_split': v.split.value_counts().to_dict(),
            'labeled_videos_by_split': self.labels.split.value_counts().to_dict(),
            'video_date_min': str(v.create_time.min()), 'video_date_max': str(v.create_time.max()),
            'videos_after_2025_06_30': int((v.create_time > pd.Timestamp('2025-06-30 23:59:59')).sum()),
            'video_url_domains': v.video_url.str.extract(r'https?://([^/]+)')[0].value_counts().to_dict(),
            'video_raw_media_files': 0,
            'extracted_media_features_loaded': bool(self.media_feature_path),
            'media_slices': self.media_slices,
            'video_metadata_slices': self.video_metadata_slices,
            'events_in_early_window': len(self.events),
            'cascade_rows': int(len(self.tables['cascades'])),
            'cascade_video_count': int(self.tables['cascades'].video_id.nunique()),
            'interaction_rows': len(interaction),
            'split_date_ranges': {name: {'earliest': str(df.create_time.min()),
                                         'latest': str(df.create_time.max())}
                                  for name, df in sp.groupby('split')},
            'scope_mean_train_log': self.scope_mean,
            'scope_std_train_log': self.scope_std,
            'label_definition': 'Unique cascade participants (excluding author) within seven days',
            'peak_definition': 'Highest daily unique cascade participation in seven days',
            'rank_definition': 'Top-20 observed cascade participants by later follower reach with exponential time decay',
            'input_window': f'First {self.observation_days} days of observed events',
        }

    def export(self, output: str | Path):
        p = Path(output)
        p.mkdir(parents=True, exist_ok=True)
        (p/'audit.json').write_text(json.dumps(self.audit(), indent=2), encoding='utf-8')
        self.labels.to_csv(p/'targets.csv', index=False)
        self.videos[['video_id','create_time','split']].to_csv(p/'verified_splits.csv', index=False)
