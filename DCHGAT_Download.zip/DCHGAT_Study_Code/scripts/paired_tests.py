#!/usr/bin/env python3
"""Evaluate paired differences against fixed tabular and degree baselines."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy import stats

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from dchgat.data import CulturalDataset


def _test(difference):
    """A difference is always graph error minus baseline error."""
    difference = np.asarray(difference, dtype=float)
    valid = difference[np.isfinite(difference)]
    if len(valid) < 3:
        return {'n': len(valid), 'mean_difference': None, 'p_paired_t': None,
                'p_wilcoxon': None}
    return {'n': int(len(valid)), 'mean_difference': float(valid.mean()),
            'p_paired_t': float(stats.ttest_1samp(valid, 0).pvalue),
            'p_wilcoxon': float(stats.wilcoxon(valid).pvalue)}


def compare(data: CulturalDataset, folder: Path):
    predictions = sorted(folder.glob('full_seed_*/test_predictions.csv'))
    if len(predictions) != 5:
        raise ValueError('Five held-out seed prediction files are required.')
    baseline = pd.read_csv(folder / 'baselines' / 'baseline_test_predictions.csv')
    mean_pred = None
    for filename in predictions:
        current = pd.read_csv(filename).sort_values('video_id')
        if mean_pred is None:
            mean_pred = current[['video_id', 'z_scope', 'peak_day']].copy()
            mean_pred['reach_pred_sum'] = 0.0
            mean_pred['peak_pred_sum'] = 0.0
            mean_pred['f1_sum'] = 0.0
        elif current.video_id.tolist() != mean_pred.video_id.tolist():
            raise ValueError('Every run must evaluate the same videos.')
        mean_pred['reach_pred_sum'] += current.z_pred.to_numpy()
        mean_pred['peak_pred_sum'] += current.peak_pred.to_numpy()
        mean_pred['f1_sum'] += current.f1_at_20.to_numpy()
    mean_pred['graph_reach_pred'] = mean_pred.pop('reach_pred_sum') / len(predictions)
    mean_pred['graph_peak_pred'] = mean_pred.pop('peak_pred_sum') / len(predictions)
    mean_pred['graph_f1_at_20'] = mean_pred.pop('f1_sum') / len(predictions)
    result = mean_pred.merge(baseline[['video_id', 'RandomForest_z_scope_pred',
                                       'RandomForest_peak_pred']], on='video_id', validate='one_to_one')
    reach_graph = np.abs(result.z_scope - result.graph_reach_pred)
    reach_baseline = np.abs(result.z_scope - result.RandomForest_z_scope_pred)
    peak_graph = np.abs(result.peak_day - result.graph_peak_pred)
    peak_baseline = np.abs(result.peak_day - result.RandomForest_peak_pred)
    result['reach_abs_error_difference'] = reach_graph - reach_baseline
    result['peak_abs_error_difference'] = peak_graph - peak_baseline

    follows = data.tables['edges_user_follow']
    global_degree = follows.dst_user_id.value_counts()
    top_users = [data.uid[u] for u in global_degree.index if u in data.uid][:20]
    ranking_baseline = set(top_users)
    vid_lookup = dict(zip(data.labels.video_id, data.labels.video_ix))
    degree_f1 = []
    for v in result.video_id:
        truth = set(data.rank_targets[int(vid_lookup[v])].tolist())
        degree_f1.append(len(truth & ranking_baseline) / 20)
    result['degree_f1_at_20'] = degree_f1
    result['rank_f1_difference'] = result.graph_f1_at_20 - result.degree_f1_at_20

    summaries = {'reach_absolute_error': _test(result.reach_abs_error_difference),
                 'peak_absolute_error': _test(result.peak_abs_error_difference),
                 'ranking_f1': _test(result.rank_f1_difference)}
    # Resample complete videos, retaining all three predictions in each draw.
    rng = np.random.default_rng(2026)
    for name, col in (('reach_absolute_error', 'reach_abs_error_difference'),
                      ('peak_absolute_error', 'peak_abs_error_difference'),
                      ('ranking_f1', 'rank_f1_difference')):
        values = result[col].to_numpy()
        bootstrap = np.array([values[rng.integers(len(values), size=len(values))].mean()
                              for _ in range(1000)])
        summaries[name]['bootstrap_95_mean_difference'] = [float(x) for x in np.percentile(bootstrap, [2.5, 97.5])]
    result.to_csv(folder / 'paired_test_predictions.csv', index=False)
    (folder / 'paired_comparisons.json').write_text(json.dumps(summaries, indent=2) + '\n')
    fig, axes = plt.subplots(1, 3, figsize=(13, 4.2))
    for axis, (name, caption) in zip(axes, (
        ('reach_absolute_error', 'Absolute reach error'),
        ('peak_absolute_error', 'Absolute peak-day error'),
        ('ranking_f1', 'Influence F1@20'))):
        point = summaries[name]['mean_difference']
        low, high = summaries[name]['bootstrap_95_mean_difference']
        axis.axhline(0, linestyle='--', color='#666666', linewidth=1)
        axis.errorbar([0], [point], yerr=[[point - low], [high - point]],
                      fmt='o', markersize=8, capsize=6, color='#126E82')
        axis.set_xticks([])
        axis.set_ylabel('Graph minus baseline')
        axis.set_title(caption)
        axis.grid(axis='y', alpha=0.22)
    fig.suptitle('Paired held-out differences with bootstrap intervals')
    fig.tight_layout()
    figure_folder = folder / 'figures'
    figure_folder.mkdir(exist_ok=True)
    fig.savefig(figure_folder / 'paired_baseline_differences.png', dpi=180)
    plt.close(fig)
    return summaries


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data', type=Path, default=ROOT / 'data' / 'working')
    parser.add_argument('--output', type=Path, default=ROOT / 'outputs')
    args = parser.parse_args()
    print(json.dumps(compare(CulturalDataset(args.data), args.output), indent=2))


if __name__ == '__main__':
    main()
