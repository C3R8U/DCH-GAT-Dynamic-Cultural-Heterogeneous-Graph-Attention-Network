#!/usr/bin/env python3
"""Export true clip-level frame and audio descriptors from a local media manifest."""
from __future__ import annotations

import argparse
from pathlib import Path
import sys
import numpy as np
import pandas as pd
import torch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from dchgat.media import VisualEncoder, AudioEncoder, read_keyframes, read_waveform


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--manifest',type=Path,required=True,
                        help='CSV with video_id, video_path, audio_path')
    parser.add_argument('--data',type=Path,default=ROOT/'data'/'working')
    parser.add_argument('--output',type=Path,default=ROOT/'data'/'working'/'media_features.npz')
    parser.add_argument('--device',default='cpu')
    parser.add_argument('--frames',type=int,default=8)
    parser.add_argument('--pretrained-vision',action=argparse.BooleanOptionalAction,default=True)
    args=parser.parse_args()
    from dchgat.data import CulturalDataset
    base=pd.read_csv(args.data/'videos.csv')[['video_id']]
    manifest=pd.read_csv(args.manifest)
    if manifest.video_id.duplicated().any():
        raise ValueError('The media manifest contains duplicate video IDs.')
    joined=base.merge(manifest[['video_id','video_path','audio_path']],on='video_id',how='left',validate='one_to_one')
    if joined[['video_path','audio_path']].isna().any().any():
        raise ValueError('Both media paths are required for every listed video.')
    vision=VisualEncoder(pretrained=args.pretrained_vision).to(args.device).eval()
    audio=AudioEncoder().to(args.device).eval()
    visual_features, audio_features=[],[]
    for i,row in enumerate(joined.itertuples(index=False)):
        with torch.no_grad():
            frames=read_keyframes(row.video_path,args.frames).unsqueeze(0).to(args.device)
            waveform=read_waveform(row.audio_path).unsqueeze(0).to(args.device)
            visual_features.append(vision(frames).squeeze(0).cpu().numpy())
            audio_features.append(audio(waveform).squeeze(0).cpu().numpy())
        if (i+1)%100==0:
            print('Processed',i+1,'of',len(joined),flush=True)
    args.output.parent.mkdir(parents=True,exist_ok=True)
    np.savez_compressed(args.output, video_id=joined.video_id.to_numpy(dtype=str),
                        visual=np.stack(visual_features),audio=np.stack(audio_features))
    print('Saved verified descriptors:',args.output)


if __name__=='__main__':
    main()
