#!/usr/bin/env python3
"""Compare embedding widths and attention head counts under a fixed training budget."""
from __future__ import annotations

import argparse
from dataclasses import replace
from pathlib import Path
import sys

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from dchgat.data import CulturalDataset
from dchgat.train import TrainConfig, train_one


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--data', type=Path, default=ROOT / 'data' / 'working')
    parser.add_argument('--output', type=Path, default=ROOT / 'outputs')
    parser.add_argument('--epochs', type=int, default=30)
    parser.add_argument('--seed', type=int, default=2021)
    args = parser.parse_args()
    dataset = CulturalDataset(args.data)
    base = TrainConfig(seed=args.seed, epochs=args.epochs)
    grid = [(32, 8), (64, 8), (128, 8), (256, 8),
            (128, 2), (128, 4), (128, 16)]
    records = []
    for width, heads in grid:
        experiment = f'width_{width}_heads_{heads}'
        print('Training', experiment, flush=True)
        cfg = replace(base, hidden=width, heads=heads)
        metrics = train_one(dataset, cfg, args.output / 'sensitivity' / experiment)
        records.append({'hidden': width, 'heads': heads, 'seed': args.seed,
                        'best_epoch': metrics['best_epoch'],
                        'epochs_completed': metrics['epochs_completed'],
                        **metrics['test']})
        pd.DataFrame(records).to_csv(args.output / 'hyperparameter_sensitivity.csv', index=False)

    table = pd.DataFrame(records)
    fig, axes = plt.subplots(1, 2, figsize=(11.2, 4.1))
    for ax, selection, x_col, label in (
        (axes[0], table[table.heads == 8], 'hidden', 'Embedding width'),
        (axes[1], table[table.hidden == 128], 'heads', 'Attention heads')):
        selection = selection.sort_values(x_col)
        ax.plot(selection[x_col], selection.scope_rmse_standardized, marker='o', label='Reach RMSE')
        ax.plot(selection[x_col], selection.f1_at_20, marker='s', label='Influence F1@20')
        ax.set_xlabel(label)
        ax.set_ylabel('Held-out metric')
        ax.grid(alpha=0.25)
        ax.legend()
    fig.tight_layout()
    figures = args.output / 'figures'
    figures.mkdir(exist_ok=True, parents=True)
    fig.savefig(figures / 'hyperparameter_sensitivity.png', dpi=180)
    plt.close(fig)


if __name__ == '__main__':
    main()
