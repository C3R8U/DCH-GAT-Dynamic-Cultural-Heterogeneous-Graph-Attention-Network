"""Real audiovisual feature extraction for videos stored on local disk."""
from __future__ import annotations

import math
from pathlib import Path
import cv2
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F
from torchvision.models import resnet50, ResNet50_Weights


class VisualEncoder(nn.Module):
    def __init__(self, pretrained=True):
        super().__init__()
        # The last global-pooling features are useful even when clip durations differ.
        base = resnet50(weights=ResNet50_Weights.DEFAULT if pretrained else None)
        self.backbone = nn.Sequential(*list(base.children())[:-1])
        self.output_dim = 2048

    def forward(self, frames):
        batch, steps, c, h, w = frames.shape
        x = self.backbone(frames.reshape(batch*steps, c, h, w)).flatten(1)
        return x.reshape(batch, steps, -1).mean(1)


class AudioEncoder(nn.Module):
    def __init__(self, n_mels=64, hidden=64, sample_rate=16000):
        super().__init__()
        self.sample_rate = sample_rate
        self.n_mels = n_mels
        self.bilstm = nn.LSTM(input_size=n_mels, hidden_size=hidden, batch_first=True,
                              bidirectional=True)
        self.output_dim = hidden * 2
        self.register_buffer('filterbank', self._mel_filters(512, sample_rate, n_mels), persistent=False)

    @staticmethod
    def _mel_filters(n_fft, sample_rate, bands):
        # Triangular Mel filters summarize energy without relying on a particular audio library.
        upper = 2595 * np.log10(1 + sample_rate / 2 / 700)
        hz = 700 * (10**(np.linspace(0, upper, bands + 2) / 2595) - 1)
        points = np.floor((n_fft + 1) * hz / sample_rate).astype(int)
        matrix = torch.zeros(n_fft // 2 + 1, bands)
        for i in range(bands):
            left, mid, right = points[i:i+3]
            for j in range(left, mid):
                matrix[j, i] = (j-left)/max(mid-left, 1)
            for j in range(mid, right):
                matrix[j, i] = (right-j)/max(right-mid, 1)
        return matrix

    def forward(self, waveform):
        if waveform.ndim == 1:
            waveform = waveform.unsqueeze(0)
        window = torch.hann_window(512, device=waveform.device)
        spectrogram = torch.stft(waveform, n_fft=512, hop_length=256, win_length=512,
                                 window=window, return_complex=True).abs().square()
        mel = torch.log1p(torch.matmul(spectrogram.transpose(1,2), self.filterbank))
        _, (h, _) = self.bilstm(mel)
        return torch.cat((h[-2], h[-1]), dim=-1)


def read_keyframes(path: str | Path, count: int = 8, size: int = 224):
    cap = cv2.VideoCapture(str(path))
    if not cap.isOpened():
        raise FileNotFoundError(f'Cannot decode video: {path}')
    n = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    if n < 1:
        cap.release()
        raise ValueError(f'Video has no readable frames: {path}')
    frames = []
    for index in np.linspace(0, n-1, count, dtype=int):
        cap.set(cv2.CAP_PROP_POS_FRAMES, int(index))
        success, frame = cap.read()
        if not success:
            cap.release()
            raise ValueError(f'Could not read frame {index} from {path}')
        frame = cv2.cvtColor(cv2.resize(frame, (size, size)), cv2.COLOR_BGR2RGB)
        frames.append(torch.from_numpy(frame.copy()).permute(2,0,1).float() / 255)
    cap.release()
    x = torch.stack(frames)
    mean = torch.tensor([.485,.456,.406]).view(1,3,1,1)
    std = torch.tensor([.229,.224,.225]).view(1,3,1,1)
    return (x - mean) / std


def read_waveform(path: str | Path, sample_rate=16000):
    import soundfile as sf
    wave, rate = sf.read(str(path), dtype='float32')
    if wave.ndim > 1:
        wave = wave.mean(1)
    if rate != sample_rate:
        from scipy.signal import resample_poly
        divisor = math.gcd(rate, sample_rate)
        wave = resample_poly(wave, sample_rate//divisor, rate//divisor).astype(np.float32)
    return torch.from_numpy(wave)


@torch.no_grad()
def extract_local_media(video_paths, audio_paths, device='cpu', frames=8):
    """Pass genuine local files here; absent files are errors rather than silent zero vectors."""
    if len(video_paths) != len(audio_paths):
        raise ValueError('Every video must have a corresponding audio track.')
    vision = VisualEncoder(pretrained=True).to(device).eval()
    sound = AudioEncoder().to(device).eval()
    all_visual, all_audio = [], []
    for video_path, audio_path in zip(video_paths, audio_paths):
        img = read_keyframes(video_path, frames).unsqueeze(0).to(device)
        wav = read_waveform(audio_path).unsqueeze(0).to(device)
        all_visual.append(vision(img).cpu())
        all_audio.append(sound(wav).cpu())
    return torch.cat(all_visual), torch.cat(all_audio)
