# Data provenance and interpretation

The included source CSV files come from the user-provided dataset archive. The records are generated or demonstration-style data and are not authenticated exports from Douyin or Kuaishou. In particular, the video URLs use the `example.com` domain, platform membership is not stored, and no audio or visual files are present. The archive should not be represented as verified platform-wide behavioral observations.

The derived working set keeps the actual supplied records within the selected publication period. Original CSV records are preserved separately in `data/source/`; the chronological cohort and split can be rebuilt using `scripts/prepare_data.py`. Dataset counts, file checksums, and observation limitations are recorded in `configs/data_inventory.json` and `outputs/preprocessing/audit.json`.

All numerical metrics are calculated by the executable experiments on available records. Results from this bundle must not be substituted for values from a larger, independently collected audiovisual dataset. Cross-domain Yelp and media modality experiments require additional files; their numeric values are not inferred from this archive.

The integrity audit also detects a difference in temporal coverage: recorded cascade timestamps lie within four days of publication, while most standalone interaction rows fall well outside the seven-day outcome horizon. The working pipeline uses observed cascade participants for outcomes and restricts early graph inputs to the configured two-day window. These are limitations of the provided observations, not indications of complete seven-day interaction tracking.
