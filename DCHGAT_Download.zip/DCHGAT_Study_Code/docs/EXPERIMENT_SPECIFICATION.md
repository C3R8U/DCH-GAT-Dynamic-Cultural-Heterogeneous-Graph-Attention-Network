# Experimental specification

## Data and tasks

The graph contains user, video, genre, cultural-symbol, and instrument nodes. Directed relation families connect user accounts, authored videos, early participants, and cultural attributes. The included working tables cover videos published between 2024-01-01 and 2025-06-30. Training covers 2024-01-01 through 2025-03-31, validation covers 2025-04-01 through 2025-04-30, and the held-out test cohort covers 2025-05-01 through 2025-06-30.

The observed cascade file supplies participation timestamps for only a subset of videos. Reach is the distinct count of observed non-author participants with an event in `[publication, publication + 7 days)`. The time-to-peak label is the earliest integer day with the highest count of first participant events. The influence score for an observed participant is the sum of exponential time-decay weights over subsequent cascade participants that follow that account in the available follow network. The resulting highest-scoring twenty participants form the ranking target. These targets are estimators over available records, not complete platform observables.

Two daily early-interaction snapshots represent information available on days zero and one. A phase graph contains the selected phase and preceding phases; historical follower links do not have timestamps. The graph is therefore a cohort-level, partially transductive benchmark: it does not establish strictly prospective prediction at each publication time.

## Network architecture

The model uses 128-dimensional embeddings, eight attention heads, three graph attention layers, and dropout 0.5. User, video, genre, symbol, and instrument inputs have separate linear projections. Each relation uses a separate attention source vector, attention destination vector, and message scaling vector. Destination-wise softmax normalizes neighbor contributions by relation and head. Residual connections and layer normalization stabilize graph layer updates.

The higher-order routes are video-user-video, video-genre-video, video-symbol-video, video-instrument-video, and user-video-user. Their normalized sparse two-step neighbor summaries pass through a tanh semantic attention network. Learned softmax path weights control how the routes contribute to each target node. A GRU cell updates node states across two daily graph snapshots.

A video regression head predicts a standardized log reach variable. A second head predicts peak day. A user-video ranking head generates pairwise logits for influential-user candidates. The training objective is the sum of reach MSE, 0.35 times peak smooth-L1 loss, and 0.25 times sampled-pair binary cross-entropy. The task weights are explicit modeling choices in the executable configuration.

## Training and evaluation

Adam uses learning rate 0.001, weight decay 0.0005, ranking supervision batch size 1,024, and global gradient clipping 2.0. The maximum schedule is 60 epochs with patience 20. Independent initializations use seeds 2021, 2022, 2023, 2024, and 2025. The validation objective determines the checkpoint; metrics are subsequently computed on the held-out set.

The reach metrics are RMSE and MAE on the standardized log target, plus MAE in observed participant units. Peak-time metrics are MAE in days and R-squared. The ranking metrics are Precision@20, Recall@20, and F1@20 over top-20 predicted and reference sets. With both sets fixed at size twenty, these three metrics necessarily coincide for each example. Statistical summaries report cross-seed means and standard deviations plus 1,000 video-resampled bootstrap intervals.

## Multimodal input contract

The image encoder produces 2,048-dimensional averaged ResNet-50 global pooled features from uniformly sampled frames. The audio encoder transforms waveforms to log-Mel spectrograms and applies a bidirectional LSTM. These encoders are executable when local video/audio files and their mapping are supplied; the current working collection has neither. Runs in this package use structured video metadata rather than asserting an audiovisual measurement. Audio-only, visual-only, and Yelp cross-domain metrics are unavailable without those additional inputs.

## Files

- `scripts/prepare_data.py` prepares the chronological working set.
- `scripts/run_experiments.py` trains independent runs and optional ablations.
- `scripts/summarize_results.py` aggregates held-out outcomes and uncertainty.
- `scripts/inspect_attention.py` exports semantic weights.
- `scripts/analyze_subgroups.py` evaluates conditional metadata perturbation and subgroups.
- `scripts/extract_media.py` extracts authentic audiovisual descriptors from local media.
- `outputs/` contains actual logs, checkpoints, validation histories, metric tables, and figures.
