"""Training, held-out evaluation, baseline checks, and experiment files."""
from __future__ import annotations

from dataclasses import asdict, dataclass
from pathlib import Path
import json
import gc
import random
import time

import numpy as np
import pandas as pd
import torch
from torch.nn import functional as F
from sklearn.linear_model import Ridge
from sklearn.svm import SVR
from sklearn.neural_network import MLPRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.preprocessing import StandardScaler

from .model import DCHGAT


@dataclass
class TrainConfig:
    hidden: int = 128
    heads: int = 8
    layers: int = 3
    lr: float = 0.001
    weight_decay: float = 5e-4
    dropout: float = 0.5
    batch_size: int = 1024
    patience: int = 20
    epochs: int = 60
    observation_days: int = 2
    seed: int = 2021
    use_meta: bool = True
    use_temporal: bool = True
    use_content: bool = True
    use_attention: bool = True
    include_culture: bool = True
    use_visual: bool = True
    use_audio: bool = True


def seed_all(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.set_num_threads(4)


def model_for(data, cfg):
    return DCHGAT(data.sizes, {k: v.size(1) for k, v in data.features.items()},
                  hidden=cfg.hidden, heads=cfg.heads, layers=cfg.layers,
                  dropout=cfg.dropout, use_meta=cfg.use_meta,
                  use_temporal=cfg.use_temporal, use_content=cfg.use_content,
                  use_attention=cfg.use_attention, media_slices=data.media_slices,
                  use_visual=cfg.use_visual, use_audio=cfg.use_audio)


def phase_views(data, phase, cfg):
    return [data.graph(phase, day, include_culture=cfg.include_culture)
            for day in range(cfg.observation_days)]


def rank_examples(data, label_frame, seed, negatives_per_video=25):
    rng = np.random.default_rng(seed)
    vid, uid, ys = [], [], []
    n = data.n_users
    for v in label_frame.video_ix:
        positives = data.rank_targets[int(v)]
        if len(positives) < 20:
            continue
        forbidden = set(positives.tolist())
        negatives = []
        while len(negatives) < negatives_per_video:
            w = int(rng.integers(n))
            if w not in forbidden:
                forbidden.add(w)
                negatives.append(w)
        vid.extend([int(v)] * (len(positives) + len(negatives)))
        uid.extend(positives.tolist() + negatives)
        ys.extend([1.0] * len(positives) + [0.0] * len(negatives))
    return (torch.tensor(vid, dtype=torch.long),
            torch.tensor(uid, dtype=torch.long),
            torch.tensor(ys, dtype=torch.float32))


def fit_loss(data, cfg, model, embedding, partition, step):
    frame = data.labels[data.labels.split == partition]
    vi = torch.tensor(frame.video_ix.to_numpy(dtype=np.int64))
    a = torch.tensor(frame.z_scope.to_numpy(dtype=np.float32))
    b = torch.tensor(frame.peak_day.to_numpy(dtype=np.float32))
    scope = F.mse_loss(embedding['scope'][vi], a)
    peak = F.smooth_l1_loss(embedding['peak'][vi], b)
    user_v, user_u, y = rank_examples(data, frame, cfg.seed + step)
    # Each pass sees a fresh ranking batch, while the graph embeddings are shared.
    if len(y) > cfg.batch_size:
        rng = np.random.default_rng(cfg.seed * 1000 + step + (0 if partition == 'train' else 900000))
        batch = torch.from_numpy(rng.choice(len(y), size=cfg.batch_size, replace=False))
        user_v, user_u, y = user_v[batch], user_u[batch], y[batch]
    rank = F.binary_cross_entropy_with_logits(model.rank_scores(embedding['video'], embedding['user'],
                                                                user_v, user_u), y)
    loss = scope + 0.35 * peak + 0.25 * rank
    return loss, {'scope_loss': float(scope.detach()),
                  'peak_loss': float(peak.detach()), 'rank_loss': float(rank.detach())}


@torch.no_grad()
def evaluate(data, model, phase, cfg, include_predictions=True):
    model.eval()
    y = model(data.features, phase_views(data, phase, cfg), data.offset)
    frame = data.labels[data.labels.split == phase].copy()
    ix = torch.tensor(frame.video_ix.to_numpy(), dtype=torch.long)
    frame['z_pred'] = y['scope'][ix].cpu().numpy()
    frame['scope_pred'] = np.maximum(0, np.expm1(frame.z_pred * data.scope_std + data.scope_mean))
    frame['peak_pred'] = np.clip(y['peak'][ix].cpu().numpy(), 0, 6)
    f1, prec, rec, hits = [], [], [], []
    scores_all = model.rank_matrix(y['video'], y['user'], ix)
    predicted_all = torch.topk(scores_all, k=20, dim=1).indices.cpu().numpy()
    for v, predicted in zip(frame.video_ix, predicted_all):
        truth = set(data.rank_targets[int(v)].tolist())
        if len(truth) < 20:
            f1.append(np.nan); prec.append(np.nan); rec.append(np.nan); hits.append(np.nan)
            continue
        predicted = set(predicted.tolist())
        overlap = len(predicted & truth)
        # Both ground-truth and predicted sets contain exactly twenty users.
        p = overlap / 20
        prec.append(p); rec.append(p); f1.append(p); hits.append(overlap)
    frame['precision_at_20'] = prec
    frame['recall_at_20'] = rec
    frame['f1_at_20'] = f1
    frame['top_20_hits'] = hits
    truth_z = frame.z_scope.to_numpy()
    prediction_z = frame.z_pred.to_numpy()
    yp = frame.peak_day.to_numpy()
    pp = frame.peak_pred.to_numpy()
    scores = {
        'count': int(len(frame)),
        'scope_rmse_standardized': float(np.sqrt(mean_squared_error(truth_z, prediction_z))),
        'scope_mae_standardized': float(mean_absolute_error(truth_z, prediction_z)),
        'scope_mae_users': float(mean_absolute_error(frame.scope, frame.scope_pred)),
        'peak_mae_days': float(mean_absolute_error(yp, pp)),
        'peak_r2': float(r2_score(yp, pp)) if len(np.unique(yp)) > 1 else None,
        'precision_at_20': float(np.nanmean(prec)),
        'recall_at_20': float(np.nanmean(rec)),
        'f1_at_20': float(np.nanmean(f1)),
        'rank_eligible_videos': int(np.isfinite(f1).sum()),
    }
    return (scores, frame) if include_predictions else scores


def train_one(data, cfg: TrainConfig, output: str | Path):
    seed_all(cfg.seed)
    folder = Path(output)
    folder.mkdir(parents=True, exist_ok=True)
    (folder/'config.json').write_text(json.dumps(asdict(cfg), indent=2))
    model = model_for(data, cfg)
    optimizer = torch.optim.Adam(model.parameters(), lr=cfg.lr, weight_decay=cfg.weight_decay)
    history = []
    best_val = float('inf')
    best_epoch = 0
    checkpoint = folder/'best_model.pt'
    elapsed = time.perf_counter()
    train_views = phase_views(data, 'train', cfg)
    val_views = phase_views(data, 'val', cfg)
    for epoch in range(1, cfg.epochs + 1):
        model.train()
        optimizer.zero_grad(set_to_none=True)
        values = model(data.features, train_views, data.offset)
        loss, pieces = fit_loss(data, cfg, model, values, 'train', epoch)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=2.0)
        optimizer.step()
        with torch.no_grad():
            model.eval()
            pred = model(data.features, val_views, data.offset)
            valid, valid_parts = fit_loss(data, cfg, model, pred, 'val', 0)
        log = {'epoch': epoch, 'train_loss': float(loss.detach()),
               'val_loss': float(valid.detach()), **pieces,
               'val_scope_loss': valid_parts['scope_loss'],
               'val_peak_loss': valid_parts['peak_loss'],
               'val_rank_loss': valid_parts['rank_loss'],
               'seconds_total': round(time.perf_counter()-elapsed, 2),
               'cgroup_memory_mb': round(int(Path('/sys/fs/cgroup/memory.current').read_text()) / 2**20, 1)
               if Path('/sys/fs/cgroup/memory.current').exists() else None}
        history.append(log)
        print(f"Epoch {epoch:03d} | train {log['train_loss']:.4f} | val {log['val_loss']:.4f} | "
              f"scope {log['val_scope_loss']:.4f} | peak {log['val_peak_loss']:.4f} | RAM {log['cgroup_memory_mb']} MB", flush=True)
        pd.DataFrame(history).to_csv(folder/'history.csv', index=False)
        if float(valid) < best_val - 1e-6:
            best_val = float(valid)
            best_epoch = epoch
            torch.save({'model_state': model.state_dict(), 'config': asdict(cfg),
                        'best_epoch': epoch}, checkpoint)
        del values, pred, loss, valid
        gc.collect()
        if epoch - best_epoch >= cfg.patience:
            break
    state = torch.load(checkpoint, map_location='cpu', weights_only=True)
    model.load_state_dict(state['model_state'])
    val_metrics, val_pred = evaluate(data, model, 'val', cfg)
    test_metrics, test_pred = evaluate(data, model, 'test', cfg)
    val_pred.to_csv(folder/'validation_predictions.csv', index=False)
    test_pred.to_csv(folder/'test_predictions.csv', index=False)
    metric = {'validation': val_metrics, 'test': test_metrics,
              'best_epoch': best_epoch, 'epochs_completed': len(history),
              'runtime_seconds': round(time.perf_counter()-elapsed, 1),
              'model_parameters': sum(x.numel() for x in model.parameters()),
              'seed': cfg.seed}
    (folder/'metrics.json').write_text(json.dumps(metric, indent=2))
    return metric


def tabular_baselines(data, output):
    """Small, interpretable comparisons keep the graph model results in perspective."""
    folder = Path(output)
    folder.mkdir(parents=True, exist_ok=True)
    l = data.labels.copy()
    events = data.events.groupby(['video_ix', 'day']).size().unstack(fill_value=0)
    for day in range(data.observation_days):
        l[f'early_{day}'] = l.video_ix.map(events.get(day, pd.Series(dtype=float))).fillna(0)
    follow = data.tables['edges_user_follow']
    degree = follow.dst_user_id.value_counts()
    l['author_followers_edges'] = l.video_ix.map(
        lambda ix: degree.get(data.videos.iloc[int(ix)].author_id, 0))
    numeric = l[['early_0', 'early_1', 'author_followers_edges']].to_numpy(dtype=float)
    features = data.features['video'][l.video_ix.to_numpy()].numpy()
    xx = np.hstack([features, np.log1p(numeric)])
    train = l.split.eq('train').to_numpy()
    test = l.split.eq('test').to_numpy()
    scaler = StandardScaler()
    xtrain = scaler.fit_transform(xx[train]); xtest = scaler.transform(xx[test])
    target = l.z_scope.to_numpy()
    result = {}
    baseline_prediction_rows = l.loc[test, ['video_id', 'video_ix', 'z_scope', 'scope', 'peak_day']].copy()
    for name, reg in {'Ridge': Ridge(alpha=10.0),
                      'SVM': SVR(C=5.0, epsilon=0.1, gamma='scale'),
                      'StructuredMLP': MLPRegressor(hidden_layer_sizes=(64,32), max_iter=400,
                                                    early_stopping=True, random_state=2021),
                      'RandomForest': RandomForestRegressor(n_estimators=100, max_depth=8,
                                                             min_samples_leaf=3, random_state=2021,
                                                             n_jobs=2)}.items():
        reg.fit(xtrain, target[train])
        pr = reg.predict(xtest)
        baseline_prediction_rows[name+'_z_scope_pred'] = pr
        result[name] = {
            'scope_rmse_standardized': float(np.sqrt(mean_squared_error(target[test], pr))),
            'scope_mae_standardized': float(mean_absolute_error(target[test], pr))}
    peak = l.peak_day.to_numpy()
    peak_ridge = Ridge(alpha=10).fit(xtrain, peak[train]).predict(xtest)
    baseline_prediction_rows['Ridge_peak_pred'] = peak_ridge
    result['Ridge']['peak_mae_days'] = float(mean_absolute_error(peak[test], peak_ridge))
    result['Ridge']['peak_r2'] = float(r2_score(peak[test], peak_ridge))
    peak_rf = RandomForestRegressor(n_estimators=100, max_depth=8, min_samples_leaf=3,
                                     random_state=2021, n_jobs=2).fit(xtrain, peak[train]).predict(xtest)
    baseline_prediction_rows['RandomForest_peak_pred'] = peak_rf
    result['RandomForest']['peak_mae_days'] = float(mean_absolute_error(peak[test], peak_rf))
    result['RandomForest']['peak_r2'] = float(r2_score(peak[test], peak_rf))
    for name, reg in {'SVM': SVR(C=5.0, epsilon=0.1, gamma='scale'),
                      'StructuredMLP': MLPRegressor(hidden_layer_sizes=(64,32), max_iter=400,
                                                    early_stopping=True, random_state=2021)}.items():
        predicted_peak = reg.fit(xtrain, peak[train]).predict(xtest)
        baseline_prediction_rows[name+'_peak_pred'] = predicted_peak
        result[name]['peak_mae_days'] = float(mean_absolute_error(peak[test],predicted_peak))
        result[name]['peak_r2'] = float(r2_score(peak[test],predicted_peak))
    deg_user = follow.dst_user_id.value_counts()
    ranked = [data.uid[user] for user in deg_user.index if user in data.uid][:20]
    rankset = set(ranked)
    rank_scores = [len(rankset & set(data.rank_targets[int(v)].tolist())) / 20
                   for v in l.loc[test, 'video_ix'] if len(data.rank_targets[int(v)]) == 20]
    result['FollowerDegree'] = {'precision_at_20': float(np.mean(rank_scores)),
                                 'recall_at_20': float(np.mean(rank_scores)),
                                 'f1_at_20': float(np.mean(rank_scores))}
    baseline_prediction_rows.to_csv(folder/'baseline_test_predictions.csv', index=False)
    (folder/'baseline_metrics.json').write_text(json.dumps(result, indent=2))
    return result
