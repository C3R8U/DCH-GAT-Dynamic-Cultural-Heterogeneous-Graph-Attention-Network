#!/usr/bin/env python3
"""Subpopulation error profiles and noncausal feature-shuffle tests."""
from __future__ import annotations

import argparse
from pathlib import Path
import sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pandas as pd

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from dchgat import CulturalDataset
from dchgat.subgroups import evaluate_groups, metadata_perturbation


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,default=ROOT/'outputs')
    parser.add_argument('--data',type=Path,default=ROOT/'data'/'working')
    parser.add_argument('--seed',type=int,default=2021)
    parser.add_argument('--repeats',type=int,default=10)
    args=parser.parse_args()
    d=CulturalDataset(args.data)
    p=args.output/f'full_seed_{args.seed}'
    out=args.output/'subgroups'
    groups=evaluate_groups(d,p/'test_predictions.csv',out)
    changes=metadata_perturbation(d,p/'best_model.pt',out,repeats=args.repeats,seed=args.seed)
    fig,axes=plt.subplots(1,2,figsize=(11,4))
    scope=groups[groups.grouping=='genre'].sort_values('group')
    axes[0].bar(scope.group,scope.scope_rmse_standardized,color='#088F8F')
    axes[0].tick_params(axis='x',labelrotation=45)
    axes[0].set_ylabel('Held-out reach RMSE');axes[0].set_title('Reach error by genre')
    names=['genre','instrument']
    mean=[changes[changes.feature==x].scope_rmse_delta.mean() for x in names]
    std=[changes[changes.feature==x].scope_rmse_delta.std(ddof=1) for x in names]
    axes[1].bar(names,mean,yerr=std,color=['#23395B','#D18F27'],capsize=5)
    axes[1].axhline(0,c='black',ls='--',lw=1)
    axes[1].set_ylabel('Change in test RMSE');axes[1].set_title('Within-month metadata shuffle')
    fig.tight_layout();fig.savefig(args.output/'figures'/'subgroup_perturbation.png',dpi=170);plt.close(fig)
    print('Saved subgroup tables and metadata perturbation diagnostics')


if __name__=='__main__':
    main()
