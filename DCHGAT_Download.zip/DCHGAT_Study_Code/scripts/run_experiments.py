#!/usr/bin/env python3
"""Command-line experiment runner with saved metrics and figures."""
from __future__ import annotations

import argparse
import json
from dataclasses import replace
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from dchgat.data import CulturalDataset
from dchgat.plots import plot_data, plot_experiments
from dchgat.train import TrainConfig, train_one, tabular_baselines


def main():
    parser=argparse.ArgumentParser(description='Dynamic cultural heterogeneous graph experiments')
    parser.add_argument('--data',type=Path,default=ROOT/'data'/'working')
    parser.add_argument('--output',type=Path,default=ROOT/'outputs')
    parser.add_argument('--media-features',type=Path,default=None,
                        help='Optional validated .npz descriptors from real local media')
    parser.add_argument('--epochs',type=int,default=60)
    parser.add_argument('--seeds',type=int,nargs='+',default=[2021,2022,2023,2024,2025])
    parser.add_argument('--ablations',action='store_true')
    parser.add_argument('--ablation-epochs',type=int,default=None)
    parser.add_argument('--skip-training',action='store_true')
    parser.add_argument('--ablation-only',action='store_true')
    args=parser.parse_args()
    args.output.mkdir(parents=True,exist_ok=True)
    data=CulturalDataset(args.data,media_features=args.media_features)
    data.export(args.output/'preprocessing')
    plot_data(data,args.output/'figures')
    tabular_baselines(data,args.output/'baselines')
    if not args.skip_training and not args.ablation_only:
        for seed in args.seeds:
            cfg=TrainConfig(epochs=args.epochs,seed=seed)
            train_one(data,cfg,args.output/f'full_seed_{seed}')
    if not args.skip_training and args.ablations:
        base=TrainConfig(epochs=args.ablation_epochs or args.epochs,seed=args.seeds[0])
        settings={'no_meta':{'use_meta':False},
                  'no_temporal':{'use_temporal':False},
                  'no_attention':{'use_attention':False},
                  'no_culture_edges':{'include_culture':False},
                  'no_content':{'use_content':False}}
        if args.media_features is not None:
            settings.update({'no_visual': {'use_visual':False},
                             'no_audio': {'use_audio':False}})
        for name,parameters in settings.items():
            print(f'\nAblation: {name}',flush=True)
            train_one(data,replace(base,**parameters),args.output/f'ablation_{name}')
    plot_experiments(data,args.output,args.output/'figures')
    print('Saved outputs to',args.output.resolve())


if __name__=='__main__':
    main()
