#!/usr/bin/env python3
"""Build the chronological working tables from the supplied CSV collection."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
START = pd.Timestamp('2024-01-01')
TRAIN_END = pd.Timestamp('2025-04-01')
VALIDATION_END = pd.Timestamp('2025-05-01')
END = pd.Timestamp('2025-07-01')


def prepare(source: Path, destination: Path) -> dict:
    """Keep the selected publication window without changing observed field values."""
    destination.mkdir(parents=True, exist_ok=True)
    videos = pd.read_csv(source / 'videos.csv')
    publication = pd.to_datetime(videos['create_time'], errors='raise')
    eligible = videos.loc[(publication >= START) & (publication < END)].copy()
    if eligible.video_id.duplicated().any():
        raise ValueError('Video identifiers must be unique.')
    allowed = set(eligible.video_id)

    # A publication date determines the partition; popularity does not affect the split.
    date = pd.to_datetime(eligible.create_time)
    splits = pd.Series('train', index=eligible.index)
    splits.loc[date >= TRAIN_END] = 'val'
    splits.loc[date >= VALIDATION_END] = 'test'
    eligible.to_csv(destination / 'videos.csv', index=False)
    pd.DataFrame({'video_id': eligible.video_id, 'split': splits}).to_csv(
        destination / 'video_split.csv', index=False)

    # Event timestamps and identities stay exactly as provided within the selected cohort.
    counts = {'videos': len(eligible)}
    for name in ('video_tags', 'video_music', 'edges_user_interactions', 'cascades'):
        rows = pd.read_csv(source / f'{name}.csv')
        subset = rows.loc[rows.video_id.isin(allowed)].copy()
        subset.to_csv(destination / f'{name}.csv', index=False)
        counts[name] = len(subset)
    for name in ('music', 'users', 'edges_user_follow'):
        rows = pd.read_csv(source / f'{name}.csv')
        rows.to_csv(destination / f'{name}.csv', index=False)
        counts[name] = len(rows)
    counts.update({'source_videos': len(videos),
                   'excluded_videos': len(videos) - len(eligible),
                   'train_videos': int((splits == 'train').sum()),
                   'val_videos': int((splits == 'val').sum()),
                   'test_videos': int((splits == 'test').sum()),
                   'date_start_inclusive': str(START.date()),
                   'date_end_exclusive': str(END.date())})
    (destination / 'data_counts.json').write_text(json.dumps(counts, indent=2) + '\n')
    return counts


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, default=ROOT / 'data' / 'source')
    parser.add_argument('--output', type=Path, default=ROOT / 'data' / 'working')
    args = parser.parse_args()
    print(json.dumps(prepare(args.source, args.output), indent=2))


if __name__ == '__main__':
    main()
