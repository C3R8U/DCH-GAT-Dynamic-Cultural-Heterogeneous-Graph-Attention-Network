#!/usr/bin/env python3
"""Check that archived inputs, trained models, logs, and summaries stay consistent."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
EXPECTED_SEEDS = (2021, 2022, 2023, 2024, 2025)


def validate(root: Path) -> dict:
    checks = {}
    inventory = json.loads((root / 'configs' / 'data_inventory.json').read_text())
    for name, digest in inventory['source_file_sha256'].items():
        actual = hashlib.sha256((root / 'data' / 'source' / name).read_bytes()).hexdigest()
        assert actual == digest, f'Source file changed: {name}'
    checks['source_checksums'] = True

    source = root / 'data' / 'working'
    videos = pd.read_csv(source / 'videos.csv')
    splits = pd.read_csv(source / 'video_split.csv')
    dates = pd.to_datetime(videos.create_time)
    assert len(videos) == 2582
    assert set(splits.split.unique()) == {'train', 'val', 'test'}
    merged = videos[['video_id', 'create_time']].merge(splits, on='video_id', validate='one_to_one')
    d = pd.to_datetime(merged.create_time)
    assert d[merged.split.eq('train')].lt('2025-04-01').all()
    assert d[merged.split.eq('val')].between('2025-04-01', '2025-04-30 23:59:59').all()
    assert d[merged.split.eq('test')].between('2025-05-01', '2025-06-30 23:59:59').all()
    checks['publication_period_and_splits'] = {k: int(v) for k, v in splits.split.value_counts().items()}

    # The only accepted results are finite values from saved test prediction tables.
    runs = []
    for seed in EXPECTED_SEEDS:
        folder = root / 'outputs' / f'full_seed_{seed}'
        metrics = json.loads((folder / 'metrics.json').read_text())
        cfg = json.loads((folder / 'config.json').read_text())
        hist = pd.read_csv(folder / 'history.csv')
        pred = pd.read_csv(folder / 'test_predictions.csv')
        assert (folder / 'best_model.pt').stat().st_size > 10000
        assert cfg['hidden'] == 128 and cfg['heads'] == 8 and cfg['layers'] == 3
        assert cfg['batch_size'] == 1024 and cfg['patience'] == 20
        assert cfg['seed'] == seed and metrics['seed'] == seed
        assert len(hist) == metrics['epochs_completed']
        assert len(hist) >= 20
        assert metrics['best_epoch'] <= len(hist)
        assert len(pred) == metrics['test']['count'] == 64
        cols = ['z_pred', 'z_scope', 'peak_pred', 'peak_day', 'f1_at_20']
        assert np.isfinite(pred[cols].to_numpy()).all()
        runs.append({'seed': seed, 'epochs': len(hist),
                     'best_epoch': metrics['best_epoch'],
                     'reach_rmse': metrics['test']['scope_rmse_standardized'],
                     'peak_mae': metrics['test']['peak_mae_days'],
                     'f1_at_20': metrics['test']['f1_at_20']})
    checks['seed_runs'] = runs
    checks['figure_count'] = len(list((root / 'outputs' / 'figures').glob('*.png')))
    assert checks['figure_count'] >= 15
    assert not list(root.rglob('README.md'))
    checks['no_readme'] = True
    for file in list((root / 'src').rglob('*.py')) + list((root / 'scripts').rglob('*.py')):
        content = file.read_text()
        assert not any('\u4e00' <= letter <= '\u9fff' for letter in content)
    checks['english_python_code'] = True
    return checks


def main():
    result = validate(ROOT)
    output = ROOT / 'outputs' / 'package_validation.json'
    output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
