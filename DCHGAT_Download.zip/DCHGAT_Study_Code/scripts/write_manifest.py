#!/usr/bin/env python3
"""Record the executable inputs and output inventory in one compact JSON file."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    out = ROOT / 'outputs'
    files = []
    for folder in ('src', 'scripts', 'configs', 'data/source', 'data/working', 'docs'):
        for path in sorted((ROOT / folder).rglob('*')):
            if path.is_file() and '__pycache__' not in path.parts and path.suffix != '.pyc':
                files.append({'path': str(path.relative_to(ROOT)),
                              'bytes': path.stat().st_size,
                              'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
    runs = []
    for file in sorted(out.glob('full_seed_*/metrics.json')):
        metrics = json.loads(file.read_text())
        runs.append({'seed': metrics['seed'], 'epochs': metrics['epochs_completed'],
                     'best_epoch': metrics['best_epoch'],
                     'test_count': metrics['test']['count']})
    experiment = {'input_files': files, 'completed_runs': runs,
                  'ablation_names': sorted(p.name.replace('ablation_', '')
                                           for p in out.glob('ablation_*/metrics.json')),
                  'image_files': sorted(p.name for p in (out / 'figures').glob('*.png')),
                  'metric_files': sorted(str(p.relative_to(out)) for p in out.rglob('metrics.json')),
                  'source_count': len(list((ROOT / 'data/source').glob('*.csv'))),
                  'working_count': len(list((ROOT / 'data/working').glob('*.csv')))}
    (out / 'file_manifest.json').write_text(json.dumps(experiment, indent=2) + '\n')
    print('Manifest files', len(files), 'runs', len(runs), 'ablations', len(experiment['ablation_names']))


if __name__ == '__main__':
    main()
